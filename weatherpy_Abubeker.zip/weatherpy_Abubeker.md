
WeatherPy Assignment
The observed trends are
1.Temperature is high near the equator and decreases in going away from the equator.
2.High humidity is observed near the equator
3.Cloudiness seems uniform all over the globe


```python
# Dependencies
import csv
import random
import matplotlib.pyplot as plt
import requests
import pandas as pd
from weather_config import api_key
from citipy import citipy
```


```python
#Generating latitude(-90,90) and longitude(_180,180)
def city_generator(cities, countries):
    '''
    Returns a list of randomly generated lat, lng coordinates of the closest city
    '''
    lat, lng = random.uniform(-90, 90), random.uniform(-180, 180)
    city = citipy.nearest_city(lat, lng)
    
    city_name = city.city_name.title()
    country = city.country_code
    
    if city_name in cities and country in countries:
        city_detail = city_generator(cities, countries)[2]
    else:
        city_detail = city_name+','+country
        
    return [lat, lng, city_detail]
```


```python
#request current weather
# Save config information.
url = "http://api.openweathermap.org/data/2.5/weather?"
units = "imperial"

# Build partial query URL
query_url = f"{url}appid={api_key}&units={units}&q="

#set up number of cities to query
record = 1
Total_cities = 600

#Initiating lists for storing results

cities = []
countries = []
lat = []
lon = []
Temperature = []
humidity = []
cloudiness = []
windSpeed =[]


while record <= Total_cities:
    
    #generate random city
    city_list = city_generator(cities, countries)
    print(f' Processing for city # {record}:{city_list[2]}\n Requested: {query_url}{city_list[2]}' )
    
    r = requests.get(query_url + city_list[2])
    
    if r.status_code == 200:
        response = r.json()
        #pprint(response)
        try:
            city = response['name']
            country = response['sys']['country']
            #To Check if city is unique
            if  city in cities and country in countries:
                print(f'   {city}, {country} has already been added, attempting with another city\n')
            else:
                print('   recording weather for ' f'{city}, {country}' '\n')
                
                lat.append(response['coord']['lat'])
                lon.append(response['coord']['lon'])
                Temperature.append(response['main']['temp'])
                humidity.append(response['main']['humidity'])
                cloudiness.append(response['clouds']['all'])
                windSpeed.append(response['wind']['speed'])
                cities.append(city)
                countries.append(country)
                record += 1
        except KeyError:
            print('Key is not found')
    elif r.status_code == 404:
        print('   city not found, retrying with different city... \n')
        
print( f'Requested for {len(cities)} cities.' )

```

     Processing for city # 1:Katsuura,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Katsuura,jp
       recording weather for Katsuura, JP
    
     Processing for city # 2:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       recording weather for Port Alfred, ZA
    
     Processing for city # 3:Airai,pw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Airai,pw
       city not found, retrying with different city... 
    
     Processing for city # 3:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       recording weather for Ushuaia, AR
    
     Processing for city # 4:Pangnirtung,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pangnirtung,ca
       recording weather for Pangnirtung, CA
    
     Processing for city # 5:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       recording weather for Busselton, AU
    
     Processing for city # 6:Oistins,bb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Oistins,bb
       recording weather for Oistins, BB
    
     Processing for city # 7:Nantucket,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nantucket,us
       recording weather for Nantucket, US
    
     Processing for city # 8:Berlevag,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Berlevag,no
       recording weather for Berlevag, NO
    
     Processing for city # 9:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       recording weather for Qaanaaq, GL
    
     Processing for city # 10:Juneau,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Juneau,us
       recording weather for Juneau, US
    
     Processing for city # 11:Norman Wells,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Norman Wells,ca
       recording weather for Norman Wells, CA
    
     Processing for city # 12:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       recording weather for Albany, AU
    
     Processing for city # 13:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       recording weather for Chuy, UY
    
     Processing for city # 14:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       recording weather for Hobart, AU
    
     Processing for city # 15:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       recording weather for Cape Town, ZA
    
     Processing for city # 16:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       recording weather for Hermanus, ZA
    
     Processing for city # 17:Cotonou,bj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cotonou,bj
       recording weather for Cotonou, BJ
    
     Processing for city # 18:Langsa,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Langsa,id
       recording weather for Langsa, ID
    
     Processing for city # 19:Cikampek,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cikampek,id
       recording weather for Cikampek, ID
    
     Processing for city # 20:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       recording weather for Mahebourg, MU
    
     Processing for city # 21:Amderma,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Amderma,ru
       city not found, retrying with different city... 
    
     Processing for city # 21:Asau,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asau,tv
       city not found, retrying with different city... 
    
     Processing for city # 21:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       recording weather for New Norfolk, AU
    
     Processing for city # 22:Kaitangata,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kaitangata,nz
       recording weather for Kaitangata, NZ
    
     Processing for city # 23:Bulgan,mn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bulgan,mn
       recording weather for Bulgan, MN
    
     Processing for city # 24:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 24:Mullaitivu,lk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mullaitivu,lk
       city not found, retrying with different city... 
    
     Processing for city # 24:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 24:Longyearbyen,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Longyearbyen,sj
       recording weather for Longyearbyen, SJ
    
     Processing for city # 25:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       recording weather for Cherskiy, RU
    
     Processing for city # 26:Batagay-Alyta,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Batagay-Alyta,ru
       recording weather for Batagay-Alyta, RU
    
     Processing for city # 27:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 27:Jaisalmer,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jaisalmer,in
       recording weather for Jaisalmer, IN
    
     Processing for city # 28:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       recording weather for Torbay, CA
    
     Processing for city # 29:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       recording weather for Chokurdakh, RU
    
     Processing for city # 30:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       recording weather for Jamestown, SH
    
     Processing for city # 31:Talnakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Talnakh,ru
       recording weather for Talnakh, RU
    
     Processing for city # 32:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       recording weather for Ponta do Sol, CV
    
     Processing for city # 33:Pierre,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pierre,us
       recording weather for Pierre, US
    
     Processing for city # 34:Umzimvubu,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Umzimvubu,za
       city not found, retrying with different city... 
    
     Processing for city # 34:The Valley,ai
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=The Valley,ai
       recording weather for The Valley, AI
    
     Processing for city # 35:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 35:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       recording weather for Rikitea, PF
    
     Processing for city # 36:Asau,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asau,tv
       city not found, retrying with different city... 
    
     Processing for city # 36:San Felipe,ve
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Felipe,ve
       recording weather for San Felipe, VE
    
     Processing for city # 37:Siocon,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Siocon,ph
       recording weather for Siocon, PH
    
     Processing for city # 38:Constitucion,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Constitucion,cl
       recording weather for Constitucion, CL
    
     Processing for city # 39:Hervey Bay,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hervey Bay,au
       recording weather for Hervey Bay, AU
    
     Processing for city # 40:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 40:Jaragua,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jaragua,br
       recording weather for Jaragua, BR
    
     Processing for city # 41:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 41:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       recording weather for Khatanga, RU
    
     Processing for city # 42:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       recording weather for Kapaa, US
    
     Processing for city # 43:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 43:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 43:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 43:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       recording weather for Castro, CL
    
     Processing for city # 44:Nizhniy Odes,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhniy Odes,ru
       recording weather for Nizhniy Odes, RU
    
     Processing for city # 45:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       recording weather for Punta Arenas, CL
    
     Processing for city # 46:Camacha,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Camacha,pt
       recording weather for Camacha, PT
    
     Processing for city # 47:Tabou,ci
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tabou,ci
       recording weather for Tabou, CI
    
     Processing for city # 48:Lompoc,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lompoc,us
       recording weather for Lompoc, US
    
     Processing for city # 49:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       recording weather for Arraial do Cabo, BR
    
     Processing for city # 50:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 50:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 50:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       recording weather for Vaini, TO
    
     Processing for city # 51:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 51:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 51:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 51:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 51:Maniitsoq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maniitsoq,gl
       recording weather for Maniitsoq, GL
    
     Processing for city # 52:Mayo,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mayo,ca
       recording weather for Mayo, CA
    
     Processing for city # 53:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 53:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       recording weather for Butaritari, KI
    
     Processing for city # 54:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 54:Qasigiannguit,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qasigiannguit,gl
       recording weather for Qasigiannguit, GL
    
     Processing for city # 55:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       recording weather for Avarua, CK
    
     Processing for city # 56:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 56:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       recording weather for Bethel, US
    
     Processing for city # 57:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       recording weather for Atuona, PF
    
     Processing for city # 58:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 58:Aporawan,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aporawan,ph
       city not found, retrying with different city... 
    
     Processing for city # 58:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       recording weather for Kodiak, US
    
     Processing for city # 59:Krasnoborsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Krasnoborsk,ru
       recording weather for Krasnoborsk, RU
    
     Processing for city # 60:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 60:Ecoporanga,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ecoporanga,br
       recording weather for Ecoporanga, BR
    
     Processing for city # 61:Bajil,ye
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bajil,ye
       recording weather for Bajil, YE
    
     Processing for city # 62:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 62:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       recording weather for Tuktoyaktuk, CA
    
     Processing for city # 63:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       recording weather for Ribeira Grande, PT
    
     Processing for city # 64:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 64:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 64:Itacarambi,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Itacarambi,br
       recording weather for Itacarambi, BR
    
     Processing for city # 65:Luangwa,zm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luangwa,zm
       recording weather for Luangwa, ZM
    
     Processing for city # 66:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 66:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 66:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 66:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 66:Whitley Bay,gb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Whitley Bay,gb
       recording weather for Whitley Bay, GB
    
     Processing for city # 67:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       recording weather for Port Elizabeth, ZA
    
     Processing for city # 68:Lebu,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lebu,cl
       recording weather for Lebu, CL
    
     Processing for city # 69:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 69:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       recording weather for Sao Filipe, CV
    
     Processing for city # 70:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 70:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 70:Khandyga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khandyga,ru
       recording weather for Khandyga, RU
    
     Processing for city # 71:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 71:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 71:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 71:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 71:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       recording weather for Hilo, US
    
     Processing for city # 72:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       recording weather for Tasiilaq, GL
    
     Processing for city # 73:Coihaique,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Coihaique,cl
       recording weather for Coihaique, CL
    
     Processing for city # 74:Azul,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Azul,ar
       recording weather for Azul, AR
    
     Processing for city # 75:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       recording weather for Dikson, RU
    
     Processing for city # 76:Chicama,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chicama,pe
       recording weather for Chicama, PE
    
     Processing for city # 77:Ixtapa,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ixtapa,mx
       recording weather for Ixtapa, MX
    
     Processing for city # 78:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 78:Williams Lake,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Williams Lake,ca
       recording weather for Williams Lake, CA
    
     Processing for city # 79:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 79:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 79:Comodoro Rivadavia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Comodoro Rivadavia,ar
       recording weather for Comodoro Rivadavia, AR
    
     Processing for city # 80:Benghazi,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Benghazi,ly
       recording weather for Benghazi, LY
    
     Processing for city # 81:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       recording weather for Tuatapere, NZ
    
     Processing for city # 82:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 82:Necochea,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Necochea,ar
       recording weather for Necochea, AR
    
     Processing for city # 83:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       recording weather for Bredasdorp, ZA
    
     Processing for city # 84:Pevek,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pevek,ru
       recording weather for Pevek, RU
    
     Processing for city # 85:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       recording weather for Yellowknife, CA
    
     Processing for city # 86:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 86:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 86:Isla Mujeres,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Isla Mujeres,mx
       recording weather for Isla Mujeres, MX
    
     Processing for city # 87:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       recording weather for Upernavik, GL
    
     Processing for city # 88:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       recording weather for Bambous Virieux, MU
    
     Processing for city # 89:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       recording weather for Faanui, PF
    
     Processing for city # 90:Bowen,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bowen,au
       recording weather for Bowen, AU
    
     Processing for city # 91:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 91:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 91:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 91:Hobyo,so
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobyo,so
       recording weather for Hobyo, SO
    
     Processing for city # 92:Umm Kaddadah,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Umm Kaddadah,sd
       recording weather for Umm Kaddadah, SD
    
     Processing for city # 93:La Rioja,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=La Rioja,ar
       recording weather for La Rioja, AR
    
     Processing for city # 94:Bat Yam,il
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bat Yam,il
       recording weather for Bat Yam, IL
    
     Processing for city # 95:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 95:Fairbanks,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fairbanks,us
       recording weather for Fairbanks, US
    
     Processing for city # 96:Fortuna,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fortuna,us
       recording weather for Fortuna, US
    
     Processing for city # 97:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 97:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 97:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 97:Paamiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Paamiut,gl
       recording weather for Paamiut, GL
    
     Processing for city # 98:Siocon,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Siocon,ph
       Siocon, PH has already been added, attempting with another city
    
     Processing for city # 98:Temaraia,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Temaraia,ki
       city not found, retrying with different city... 
    
     Processing for city # 98:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 98:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 98:Husavik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Husavik,is
       recording weather for Husavik, IS
    
     Processing for city # 99:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 99:Palabuhanratu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Palabuhanratu,id
       city not found, retrying with different city... 
    
     Processing for city # 99:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 99:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 99:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 99:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 99:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       recording weather for Puerto Ayora, EC
    
     Processing for city # 100:Kruisfontein,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kruisfontein,za
       recording weather for Kruisfontein, ZA
    
     Processing for city # 101:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 101:Saleaula,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saleaula,ws
       city not found, retrying with different city... 
    
     Processing for city # 101:Belyy Yar,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belyy Yar,ru
       recording weather for Belyy Yar, RU
    
     Processing for city # 102:Moindou,nc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moindou,nc
       recording weather for Moindou, NC
    
     Processing for city # 103:North Bend,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=North Bend,us
       recording weather for North Bend, US
    
     Processing for city # 104:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 104:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 104:Saint-Philippe,re
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Philippe,re
       recording weather for Saint-Philippe, RE
    
     Processing for city # 105:Channel-Port Aux Basques,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Channel-Port Aux Basques,ca
       recording weather for Channel-Port aux Basques, CA
    
     Processing for city # 106:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 106:Lagoa,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lagoa,pt
       recording weather for Lagoa, PT
    
     Processing for city # 107:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       Faanui, PF has already been added, attempting with another city
    
     Processing for city # 107:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 107:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 107:Saryozek,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saryozek,kz
       recording weather for Saryozek, KZ
    
     Processing for city # 108:Baghdad,iq
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Baghdad,iq
       recording weather for Baghdad, IQ
    
     Processing for city # 109:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       recording weather for Bluff, NZ
    
     Processing for city # 110:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       recording weather for Tiksi, RU
    
     Processing for city # 111:Biltine,td
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Biltine,td
       recording weather for Biltine, TD
    
     Processing for city # 112:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 112:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 112:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 112:Kokopo,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kokopo,pg
       recording weather for Kokopo, PG
    
     Processing for city # 113:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       recording weather for Narsaq, GL
    
     Processing for city # 114:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 114:Puerto Carreno,co
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Carreno,co
       recording weather for Puerto Carreno, CO
    
     Processing for city # 115:Pangody,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pangody,ru
       recording weather for Pangody, RU
    
     Processing for city # 116:Haradok,by
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haradok,by
       recording weather for Haradok, BY
    
     Processing for city # 117:Pevek,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pevek,ru
       Pevek, RU has already been added, attempting with another city
    
     Processing for city # 117:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 117:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 117:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       recording weather for Barrow, US
    
     Processing for city # 118:Huanren,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Huanren,cn
       recording weather for Huanren, CN
    
     Processing for city # 119:Leh,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leh,in
       recording weather for Leh, IN
    
     Processing for city # 120:Adrar,dz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Adrar,dz
       recording weather for Adrar, DZ
    
     Processing for city # 121:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 121:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 121:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 121:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 121:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 121:Marawi,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marawi,sd
       recording weather for Marawi, SD
    
     Processing for city # 122:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 122:Tsihombe,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tsihombe,mg
       city not found, retrying with different city... 
    
     Processing for city # 122:Morondava,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Morondava,mg
       recording weather for Morondava, MG
    
     Processing for city # 123:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       recording weather for Saskylakh, RU
    
     Processing for city # 124:Nosy Varika,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nosy Varika,mg
       recording weather for Nosy Varika, MG
    
     Processing for city # 125:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 125:Sitka,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sitka,us
       recording weather for Sitka, US
    
     Processing for city # 126:Chiredzi,zw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chiredzi,zw
       recording weather for Chiredzi, ZW
    
     Processing for city # 127:Chapais,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chapais,ca
       recording weather for Chapais, CA
    
     Processing for city # 128:Vestmannaeyjar,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vestmannaeyjar,is
       recording weather for Vestmannaeyjar, IS
    
     Processing for city # 129:Victoria,sc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Victoria,sc
       recording weather for Victoria, SC
    
     Processing for city # 130:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 130:Mareeba,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mareeba,au
       recording weather for Mareeba, AU
    
     Processing for city # 131:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 131:Ruatoria,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ruatoria,nz
       city not found, retrying with different city... 
    
     Processing for city # 131:Bayji,iq
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bayji,iq
       recording weather for Bayji, IQ
    
     Processing for city # 132:Flinders,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Flinders,au
       recording weather for Flinders, AU
    
     Processing for city # 133:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 133:Kabanjahe,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kabanjahe,id
       recording weather for Kabanjahe, ID
    
     Processing for city # 134:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 134:Korcula,hr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Korcula,hr
       recording weather for Korcula, HR
    
     Processing for city # 135:Pachperwa,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pachperwa,in
       recording weather for Pachperwa, IN
    
     Processing for city # 136:Norman Wells,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Norman Wells,ca
       Norman Wells, CA has already been added, attempting with another city
    
     Processing for city # 136:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       recording weather for Mar del Plata, AR
    
     Processing for city # 137:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 137:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 137:Ancud,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ancud,cl
       recording weather for Ancud, CL
    
     Processing for city # 138:Louisbourg,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Louisbourg,ca
       city not found, retrying with different city... 
    
     Processing for city # 138:Ouango,cf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ouango,cf
       city not found, retrying with different city... 
    
     Processing for city # 138:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 138:Hofn,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hofn,is
       recording weather for Hofn, IS
    
     Processing for city # 139:Baculin,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Baculin,ph
       recording weather for Baculin, PH
    
     Processing for city # 140:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       recording weather for Nikolskoye, RU
    
     Processing for city # 141:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       Faanui, PF has already been added, attempting with another city
    
     Processing for city # 141:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 141:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       recording weather for Georgetown, SH
    
     Processing for city # 142:Adrar,dz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Adrar,dz
       Adrar, DZ has already been added, attempting with another city
    
     Processing for city # 142:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 142:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 142:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 142:Shingu,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shingu,jp
       recording weather for Shingu, JP
    
     Processing for city # 143:Asau,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asau,tv
       city not found, retrying with different city... 
    
     Processing for city # 143:Carbonia,it
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carbonia,it
       recording weather for Carbonia, IT
    
     Processing for city # 144:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 144:Ancud,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ancud,cl
       Ancud, CL has already been added, attempting with another city
    
     Processing for city # 144:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 144:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 144:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 144:Eureka,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Eureka,us
       recording weather for Eureka, US
    
     Processing for city # 145:Aklavik,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aklavik,ca
       recording weather for Aklavik, CA
    
     Processing for city # 146:Kavieng,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kavieng,pg
       recording weather for Kavieng, PG
    
     Processing for city # 147:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 147:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 147:Puerto Ayacucho,ve
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayacucho,ve
       recording weather for Puerto Ayacucho, VE
    
     Processing for city # 148:Katsuura,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Katsuura,jp
       Katsuura, JP has already been added, attempting with another city
    
     Processing for city # 148:Longyearbyen,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Longyearbyen,sj
       Longyearbyen, SJ has already been added, attempting with another city
    
     Processing for city # 148:Grand Gaube,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand Gaube,mu
       recording weather for Grand Gaube, MU
    
     Processing for city # 149:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 149:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 149:Amderma,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Amderma,ru
       city not found, retrying with different city... 
    
     Processing for city # 149:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 149:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 149:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 149:Vila Velha,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vila Velha,br
       recording weather for Vila Velha, BR
    
     Processing for city # 150:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 150:Kavieng,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kavieng,pg
       Kavieng, PG has already been added, attempting with another city
    
     Processing for city # 150:San Juan,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Juan,ar
       recording weather for San Juan, AR
    
     Processing for city # 151:Port Lincoln,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Lincoln,au
       recording weather for Port Lincoln, AU
    
     Processing for city # 152:Vila Velha,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vila Velha,br
       Vila Velha, BR has already been added, attempting with another city
    
     Processing for city # 152:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 152:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 152:Nalut,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nalut,ly
       recording weather for Nalut, LY
    
     Processing for city # 153:Saint-Philippe,re
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Philippe,re
       Saint-Philippe, RE has already been added, attempting with another city
    
     Processing for city # 153:Vilyuysk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vilyuysk,ru
       recording weather for Vilyuysk, RU
    
     Processing for city # 154:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 154:Cap-Aux-Meules,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cap-Aux-Meules,ca
       recording weather for Cap-aux-Meules, CA
    
     Processing for city # 155:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 155:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       recording weather for East London, ZA
    
     Processing for city # 156:Dalvik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dalvik,is
       recording weather for Dalvik, IS
    
     Processing for city # 157:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 157:Toliary,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Toliary,mg
       city not found, retrying with different city... 
    
     Processing for city # 157:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 157:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 157:Buchanan,lr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Buchanan,lr
       recording weather for Buchanan, LR
    
     Processing for city # 158:Sola,vu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sola,vu
       recording weather for Sola, VU
    
     Processing for city # 159:Port Pirie,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Pirie,au
       recording weather for Port Pirie, AU
    
     Processing for city # 160:Lima,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lima,pe
       recording weather for Lima, PE
    
     Processing for city # 161:Fort Nelson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fort Nelson,ca
       recording weather for Fort Nelson, CA
    
     Processing for city # 162:Trat,th
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Trat,th
       recording weather for Trat, TH
    
     Processing for city # 163:Natal,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Natal,br
       recording weather for Natal, BR
    
     Processing for city # 164:Olafsvik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Olafsvik,is
       city not found, retrying with different city... 
    
     Processing for city # 164:Lasa,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lasa,cn
       city not found, retrying with different city... 
    
     Processing for city # 164:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 164:Tawkar,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tawkar,sd
       city not found, retrying with different city... 
    
     Processing for city # 164:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 164:Touros,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Touros,br
       recording weather for Touros, BR
    
     Processing for city # 165:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 165:Vallenar,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vallenar,cl
       recording weather for Vallenar, CL
    
     Processing for city # 166:Moose Factory,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moose Factory,ca
       recording weather for Moose Factory, CA
    
     Processing for city # 167:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 167:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 167:Grand Gaube,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand Gaube,mu
       Grand Gaube, MU has already been added, attempting with another city
    
     Processing for city # 167:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 167:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 167:Guerrero Negro,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Guerrero Negro,mx
       recording weather for Guerrero Negro, MX
    
     Processing for city # 168:Alyangula,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alyangula,au
       recording weather for Alyangula, AU
    
     Processing for city # 169:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       Faanui, PF has already been added, attempting with another city
    
     Processing for city # 169:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 169:Kalaleh,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kalaleh,ir
       recording weather for Kalaleh, IR
    
     Processing for city # 170:Atambua,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atambua,id
       recording weather for Atambua, ID
    
     Processing for city # 171:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 171:Havre-Saint-Pierre,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Havre-Saint-Pierre,ca
       recording weather for Havre-Saint-Pierre, CA
    
     Processing for city # 172:Tazovskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tazovskiy,ru
       recording weather for Tazovskiy, RU
    
     Processing for city # 173:Dingle,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dingle,ie
       recording weather for Dingle, IE
    
     Processing for city # 174:Poum,nc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Poum,nc
       recording weather for Poum, NC
    
     Processing for city # 175:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 175:Colesberg,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Colesberg,za
       recording weather for Colesberg, ZA
    
     Processing for city # 176:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       Bambous Virieux, MU has already been added, attempting with another city
    
     Processing for city # 176:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 176:Vaitupu,wf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaitupu,wf
       city not found, retrying with different city... 
    
     Processing for city # 176:Constitucion,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Constitucion,mx
       Constitucion, MX has already been added, attempting with another city
    
     Processing for city # 176:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 176:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 176:Vestmannaeyjar,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vestmannaeyjar,is
       Vestmannaeyjar, IS has already been added, attempting with another city
    
     Processing for city # 176:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 176:Godo,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Godo,jp
       recording weather for Godo, JP
    
     Processing for city # 177:Victoria,sc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Victoria,sc
       Victoria, SC has already been added, attempting with another city
    
     Processing for city # 177:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 177:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 177:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 177:Bundaberg,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bundaberg,au
       recording weather for Bundaberg, AU
    
     Processing for city # 178:Banepa,np
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Banepa,np
       recording weather for Banepa, NP
    
     Processing for city # 179:Maniitsoq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maniitsoq,gl
       Maniitsoq, GL has already been added, attempting with another city
    
     Processing for city # 179:Sorong,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sorong,id
       recording weather for Sorong, ID
    
     Processing for city # 180:Faya,td
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faya,td
       city not found, retrying with different city... 
    
     Processing for city # 180:Touros,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Touros,br
       Touros, BR has already been added, attempting with another city
    
     Processing for city # 180:Longyearbyen,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Longyearbyen,sj
       Longyearbyen, SJ has already been added, attempting with another city
    
     Processing for city # 180:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       recording weather for Carnarvon, AU
    
     Processing for city # 181:Gull Lake,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gull Lake,ca
       recording weather for Gull Lake, CA
    
     Processing for city # 182:Mount Gambier,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mount Gambier,au
       recording weather for Mount Gambier, AU
    
     Processing for city # 183:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 183:Gympie,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gympie,au
       recording weather for Gympie, AU
    
     Processing for city # 184:Esil,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esil,kz
       recording weather for Esil, KZ
    
     Processing for city # 185:Souflion,gr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Souflion,gr
       city not found, retrying with different city... 
    
     Processing for city # 185:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 185:Satitoa,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Satitoa,ws
       city not found, retrying with different city... 
    
     Processing for city # 185:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 185:Burica,pa
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Burica,pa
       city not found, retrying with different city... 
    
     Processing for city # 185:Viedma,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Viedma,ar
       recording weather for Viedma, AR
    
     Processing for city # 186:Tuy Hoa,vn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuy Hoa,vn
       recording weather for Tuy Hoa, VN
    
     Processing for city # 187:Lensk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lensk,ru
       recording weather for Lensk, RU
    
     Processing for city # 188:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 188:Simao,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Simao,cn
       recording weather for Simao, CN
    
     Processing for city # 189:Mys Shmidta,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mys Shmidta,ru
       city not found, retrying with different city... 
    
     Processing for city # 189:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 189:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 189:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 189:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 189:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 189:Bafia,cm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bafia,cm
       recording weather for Bafia, CM
    
     Processing for city # 190:Tirumullaivasal,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tirumullaivasal,in
       recording weather for Tirumullaivasal, IN
    
     Processing for city # 191:Kirakira,sb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kirakira,sb
       recording weather for Kirakira, SB
    
     Processing for city # 192:Iqaluit,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Iqaluit,ca
       recording weather for Iqaluit, CA
    
     Processing for city # 193:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 193:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 193:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 193:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 193:Senador Jose Porfirio,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Senador Jose Porfirio,br
       recording weather for Senador Jose Porfirio, BR
    
     Processing for city # 194:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 194:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 194:Olavarria,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Olavarria,ar
       recording weather for Olavarria, AR
    
     Processing for city # 195:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 195:Hit,iq
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hit,iq
       recording weather for Hit, IQ
    
     Processing for city # 196:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       recording weather for Hithadhoo, MV
    
     Processing for city # 197:Goderich,sl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Goderich,sl
       city not found, retrying with different city... 
    
     Processing for city # 197:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 197:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 197:Dahegam,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dahegam,in
       recording weather for Dahegam, IN
    
     Processing for city # 198:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 198:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 198:Fortuna,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fortuna,us
       Fortuna, US has already been added, attempting with another city
    
     Processing for city # 198:Bairiki,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bairiki,ki
       city not found, retrying with different city... 
    
     Processing for city # 198:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 198:Yokadouma,cm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yokadouma,cm
       recording weather for Yokadouma, CM
    
     Processing for city # 199:Haines Junction,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haines Junction,ca
       recording weather for Haines Junction, CA
    
     Processing for city # 200:Kahului,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kahului,us
       recording weather for Kahului, US
    
     Processing for city # 201:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 201:Cayenne,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cayenne,gf
       recording weather for Cayenne, GF
    
     Processing for city # 202:Gorontalo,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gorontalo,id
       recording weather for Gorontalo, ID
    
     Processing for city # 203:Pangnirtung,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pangnirtung,ca
       Pangnirtung, CA has already been added, attempting with another city
    
     Processing for city # 203:Temaraia,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Temaraia,ki
       city not found, retrying with different city... 
    
     Processing for city # 203:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       Bambous Virieux, MU has already been added, attempting with another city
    
     Processing for city # 203:Nelson Bay,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nelson Bay,au
       recording weather for Nelson Bay, AU
    
     Processing for city # 204:Asmara,er
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asmara,er
       recording weather for Asmara, ER
    
     Processing for city # 205:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 205:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       recording weather for Thompson, CA
    
     Processing for city # 206:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 206:Solnechnyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Solnechnyy,ru
       recording weather for Solnechnyy, RU
    
     Processing for city # 207:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 207:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 207:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 207:Livingstone,zm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Livingstone,zm
       recording weather for Livingstone, ZM
    
     Processing for city # 208:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 208:Saint George,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint George,bm
       recording weather for Saint George, BM
    
     Processing for city # 209:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 209:Caravelas,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Caravelas,br
       recording weather for Caravelas, BR
    
     Processing for city # 210:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 210:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 210:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 210:Alofi,nu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alofi,nu
       recording weather for Alofi, NU
    
     Processing for city # 211:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 211:Sakete,bj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sakete,bj
       recording weather for Sakete, BJ
    
     Processing for city # 212:Burgeo,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Burgeo,ca
       recording weather for Burgeo, CA
    
     Processing for city # 213:San Vicente,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Vicente,ph
       recording weather for San Vicente, PH
    
     Processing for city # 214:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 214:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 214:Airai,pw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Airai,pw
       city not found, retrying with different city... 
    
     Processing for city # 214:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 214:Saleaula,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saleaula,ws
       city not found, retrying with different city... 
    
     Processing for city # 214:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 214:Nome,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nome,us
       recording weather for Nome, US
    
     Processing for city # 215:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 215:Sitka,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sitka,us
       Sitka, US has already been added, attempting with another city
    
     Processing for city # 215:Nsanje,mw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nsanje,mw
       recording weather for Nsanje, MW
    
     Processing for city # 216:Kuching,my
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kuching,my
       recording weather for Kuching, MY
    
     Processing for city # 217:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 217:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 217:Suslovo,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Suslovo,ru
       recording weather for Suslovo, RU
    
     Processing for city # 218:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 218:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 218:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 218:Obidos,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Obidos,br
       city not found, retrying with different city... 
    
     Processing for city # 218:Verkhoyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Verkhoyansk,ru
       recording weather for Verkhoyansk, RU
    
     Processing for city # 219:Grand River South East,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand River South East,mu
       city not found, retrying with different city... 
    
     Processing for city # 219:Den Helder,nl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Den Helder,nl
       recording weather for Den Helder, NL
    
     Processing for city # 220:Leningradskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leningradskiy,ru
       recording weather for Leningradskiy, RU
    
     Processing for city # 221:Shar,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shar,kz
       recording weather for Shar, KZ
    
     Processing for city # 222:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 222:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 222:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 222:Murdochville,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Murdochville,ca
       recording weather for Murdochville, CA
    
     Processing for city # 223:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 223:Amderma,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Amderma,ru
       city not found, retrying with different city... 
    
     Processing for city # 223:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       Carnarvon, AU has already been added, attempting with another city
    
     Processing for city # 223:Aksum,et
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aksum,et
       recording weather for Aksum, ET
    
     Processing for city # 224:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 224:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 224:Cidreira,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cidreira,br
       recording weather for Cidreira, BR
    
     Processing for city # 225:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 225:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 225:Langangen,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Langangen,no
       city not found, retrying with different city... 
    
     Processing for city # 225:Madera,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Madera,mx
       recording weather for Madera, MX
    
     Processing for city # 226:Meulaboh,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Meulaboh,id
       recording weather for Meulaboh, ID
    
     Processing for city # 227:Zhigansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Zhigansk,ru
       recording weather for Zhigansk, RU
    
     Processing for city # 228:Mehamn,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mehamn,no
       recording weather for Mehamn, NO
    
     Processing for city # 229:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       recording weather for Clyde River, CA
    
     Processing for city # 230:Lompoc,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lompoc,us
       Lompoc, US has already been added, attempting with another city
    
     Processing for city # 230:Cuyo,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cuyo,ph
       recording weather for Cuyo, PH
    
     Processing for city # 231:Porbandar,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Porbandar,in
       recording weather for Porbandar, IN
    
     Processing for city # 232:Angoram,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Angoram,pg
       recording weather for Angoram, PG
    
     Processing for city # 233:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 233:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 233:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 233:Lahat,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lahat,id
       recording weather for Lahat, ID
    
     Processing for city # 234:Constitucion,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Constitucion,mx
       Constitucion, MX has already been added, attempting with another city
    
     Processing for city # 234:Nizhneyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhneyansk,ru
       city not found, retrying with different city... 
    
     Processing for city # 234:Fortuna,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fortuna,us
       Fortuna, US has already been added, attempting with another city
    
     Processing for city # 234:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 234:Esperance,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esperance,au
       recording weather for Esperance, AU
    
     Processing for city # 235:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 235:Kihei,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kihei,us
       recording weather for Kihei, US
    
     Processing for city # 236:Saginaw,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saginaw,us
       recording weather for Saginaw, US
    
     Processing for city # 237:Winnemucca,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Winnemucca,us
       recording weather for Winnemucca, US
    
     Processing for city # 238:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 238:Ballina,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ballina,ie
       recording weather for Ballina, IE
    
     Processing for city # 239:Sao Jose Da Coroa Grande,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Jose Da Coroa Grande,br
       recording weather for Sao Jose da Coroa Grande, BR
    
     Processing for city # 240:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 240:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 240:Agadez,ne
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Agadez,ne
       recording weather for Agadez, NE
    
     Processing for city # 241:Vostok,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vostok,ru
       recording weather for Vostok, RU
    
     Processing for city # 242:Ribeira Brava,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Brava,cv
       city not found, retrying with different city... 
    
     Processing for city # 242:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 242:Puquio,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puquio,pe
       recording weather for Puquio, PE
    
     Processing for city # 243:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 243:Vostok,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vostok,ru
       Vostok, RU has already been added, attempting with another city
    
     Processing for city # 243:Imbituba,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Imbituba,br
       recording weather for Imbituba, BR
    
     Processing for city # 244:Barabai,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barabai,id
       recording weather for Barabai, ID
    
     Processing for city # 245:Sisimiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sisimiut,gl
       recording weather for Sisimiut, GL
    
     Processing for city # 246:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 246:Ahipara,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ahipara,nz
       recording weather for Ahipara, NZ
    
     Processing for city # 247:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 247:Odweyne,so
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Odweyne,so
       city not found, retrying with different city... 
    
     Processing for city # 247:Caravelas,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Caravelas,br
       Caravelas, BR has already been added, attempting with another city
    
     Processing for city # 247:Taburi,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taburi,ph
       city not found, retrying with different city... 
    
     Processing for city # 247:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 247:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 247:Pitimbu,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pitimbu,br
       recording weather for Pitimbu, BR
    
     Processing for city # 248:Mormugao,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mormugao,in
       city not found, retrying with different city... 
    
     Processing for city # 248:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 248:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 248:Vernon,fr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vernon,fr
       recording weather for Vernon, FR
    
     Processing for city # 249:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 249:Ilulissat,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ilulissat,gl
       recording weather for Ilulissat, GL
    
     Processing for city # 250:Abong Mbang,cm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Abong Mbang,cm
       recording weather for Abong Mbang, CM
    
     Processing for city # 251:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 251:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 251:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 251:Moranbah,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moranbah,au
       recording weather for Moranbah, AU
    
     Processing for city # 252:Pringsewu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pringsewu,id
       recording weather for Pringsewu, ID
    
     Processing for city # 253:Oyama,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Oyama,jp
       recording weather for Oyama, JP
    
     Processing for city # 254:Puerto Del Rosario,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Del Rosario,es
       recording weather for Puerto del Rosario, ES
    
     Processing for city # 255:Padang,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Padang,id
       recording weather for Padang, ID
    
     Processing for city # 256:West Bay,ky
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=West Bay,ky
       recording weather for West Bay, KY
    
     Processing for city # 257:Nizhneyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhneyansk,ru
       city not found, retrying with different city... 
    
     Processing for city # 257:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 257:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 257:Shingu,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shingu,jp
       Shingu, JP has already been added, attempting with another city
    
     Processing for city # 257:Santarem,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Santarem,br
       city not found, retrying with different city... 
    
     Processing for city # 257:Kirakira,sb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kirakira,sb
       Kirakira, SB has already been added, attempting with another city
    
     Processing for city # 257:La Ronge,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=La Ronge,ca
       recording weather for La Ronge, CA
    
     Processing for city # 258:Asau,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asau,tv
       city not found, retrying with different city... 
    
     Processing for city # 258:Lorengau,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lorengau,pg
       recording weather for Lorengau, PG
    
     Processing for city # 259:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 259:Athabasca,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Athabasca,ca
       recording weather for Athabasca, CA
    
     Processing for city # 260:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 260:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 260:Kasra,tn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kasra,tn
       city not found, retrying with different city... 
    
     Processing for city # 260:Oktyabrskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Oktyabrskiy,ru
       recording weather for Oktyabrskiy, RU
    
     Processing for city # 261:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 261:Perth,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Perth,au
       recording weather for Perth, AU
    
     Processing for city # 262:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 262:Katsuura,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Katsuura,jp
       Katsuura, JP has already been added, attempting with another city
    
     Processing for city # 262:Zhigansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Zhigansk,ru
       Zhigansk, RU has already been added, attempting with another city
    
     Processing for city # 262:Carauari,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carauari,br
       recording weather for Carauari, BR
    
     Processing for city # 263:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 263:Cootamundra,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cootamundra,au
       recording weather for Cootamundra, AU
    
     Processing for city # 264:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       Clyde River, CA has already been added, attempting with another city
    
     Processing for city # 264:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 264:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 264:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 264:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 264:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 264:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 264:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 264:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 264:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 264:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 264:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 264:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 264:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       Clyde River, CA has already been added, attempting with another city
    
     Processing for city # 264:Deputatskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Deputatskiy,ru
       recording weather for Deputatskiy, RU
    
     Processing for city # 265:Pesaro,it
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pesaro,it
       recording weather for Pesaro, IT
    
     Processing for city # 266:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       Clyde River, CA has already been added, attempting with another city
    
     Processing for city # 266:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       Tasiilaq, GL has already been added, attempting with another city
    
     Processing for city # 266:Zomin,uz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Zomin,uz
       recording weather for Zomin, UZ
    
     Processing for city # 267:Ponta Do Sol,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,pt
       Ponta do Sol, PT has already been added, attempting with another city
    
     Processing for city # 267:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 267:Lhanbryde,gb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lhanbryde,gb
       recording weather for Lhanbryde, GB
    
     Processing for city # 268:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 268:Chinsali,zm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chinsali,zm
       recording weather for Chinsali, ZM
    
     Processing for city # 269:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 269:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 269:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 269:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 269:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 269:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 269:Grindavik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grindavik,is
       recording weather for Grindavik, IS
    
     Processing for city # 270:Bubaque,gw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bubaque,gw
       recording weather for Bubaque, GW
    
     Processing for city # 271:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 271:Aykhal,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aykhal,ru
       recording weather for Aykhal, RU
    
     Processing for city # 272:Scarborough,gb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Scarborough,gb
       recording weather for Scarborough, GB
    
     Processing for city # 273:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 273:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 273:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 273:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 273:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 273:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 273:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 273:Sarkand,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sarkand,kz
       recording weather for Sarkand, KZ
    
     Processing for city # 274:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 274:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 274:Lasa,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lasa,cn
       city not found, retrying with different city... 
    
     Processing for city # 274:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 274:Urusha,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Urusha,ru
       recording weather for Urusha, RU
    
     Processing for city # 275:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 275:Nouadhibou,mr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nouadhibou,mr
       recording weather for Nouadhibou, MR
    
     Processing for city # 276:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 276:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 276:Baringo,ke
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Baringo,ke
       recording weather for Baringo, KE
    
     Processing for city # 277:Saint-Francois,gp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Francois,gp
       recording weather for Saint-Francois, GP
    
     Processing for city # 278:Emerald,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Emerald,au
       recording weather for Emerald, AU
    
     Processing for city # 279:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 279:Kulhudhuffushi,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kulhudhuffushi,mv
       recording weather for Kulhudhuffushi, MV
    
     Processing for city # 280:Raudeberg,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Raudeberg,no
       recording weather for Raudeberg, NO
    
     Processing for city # 281:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       Bambous Virieux, MU has already been added, attempting with another city
    
     Processing for city # 281:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       Tasiilaq, GL has already been added, attempting with another city
    
     Processing for city # 281:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 281:Namibe,ao
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Namibe,ao
       recording weather for Namibe, AO
    
     Processing for city # 282:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 282:Cabo San Lucas,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cabo San Lucas,mx
       recording weather for Cabo San Lucas, MX
    
     Processing for city # 283:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 283:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 283:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 283:Chiriguana,co
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chiriguana,co
       recording weather for Chiriguana, CO
    
     Processing for city # 284:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 284:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 284:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 284:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 284:Marcona,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marcona,pe
       city not found, retrying with different city... 
    
     Processing for city # 284:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 284:Port Hardy,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Hardy,ca
       recording weather for Port Hardy, CA
    
     Processing for city # 285:Yuxia,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yuxia,cn
       recording weather for Yuxia, CN
    
     Processing for city # 286:Harper,lr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Harper,lr
       recording weather for Harper, LR
    
     Processing for city # 287:Pavlodar,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pavlodar,kz
       recording weather for Pavlodar, KZ
    
     Processing for city # 288:Campbell River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Campbell River,ca
       recording weather for Campbell River, CA
    
     Processing for city # 289:Kruisfontein,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kruisfontein,za
       Kruisfontein, ZA has already been added, attempting with another city
    
     Processing for city # 289:Vao,nc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vao,nc
       recording weather for Vao, NC
    
     Processing for city # 290:Freeport,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Freeport,us
       recording weather for Freeport, US
    
     Processing for city # 291:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 291:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 291:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       Mar del Plata, AR has already been added, attempting with another city
    
     Processing for city # 291:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 291:Adrar,dz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Adrar,dz
       Adrar, DZ has already been added, attempting with another city
    
     Processing for city # 291:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 291:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 291:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 291:Buchanan,lr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Buchanan,lr
       Buchanan, LR has already been added, attempting with another city
    
     Processing for city # 291:Yarada,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yarada,in
       recording weather for Yarada, IN
    
     Processing for city # 292:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 292:Guerrero Negro,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Guerrero Negro,mx
       Guerrero Negro, MX has already been added, attempting with another city
    
     Processing for city # 292:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 292:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 292:Niamey,ne
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Niamey,ne
       recording weather for Niamey, NE
    
     Processing for city # 293:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 293:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 293:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 293:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 293:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 293:Srandakan,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Srandakan,id
       recording weather for Srandakan, ID
    
     Processing for city # 294:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 294:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 294:Arlit,ne
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arlit,ne
       recording weather for Arlit, NE
    
     Processing for city # 295:Vardo,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vardo,no
       recording weather for Vardo, NO
    
     Processing for city # 296:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       Clyde River, CA has already been added, attempting with another city
    
     Processing for city # 296:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 296:Conde,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Conde,br
       recording weather for Conde, BR
    
     Processing for city # 297:Iqaluit,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Iqaluit,ca
       Iqaluit, CA has already been added, attempting with another city
    
     Processing for city # 297:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 297:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 297:Luba,gq
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luba,gq
       recording weather for Luba, GQ
    
     Processing for city # 298:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 298:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 298:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 298:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 298:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 298:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 298:Bilma,ne
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bilma,ne
       recording weather for Bilma, NE
    
     Processing for city # 299:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 299:Airai,pw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Airai,pw
       city not found, retrying with different city... 
    
     Processing for city # 299:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 299:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 299:Shache,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shache,cn
       recording weather for Shache, CN
    
     Processing for city # 300:Ilulissat,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ilulissat,gl
       Ilulissat, GL has already been added, attempting with another city
    
     Processing for city # 300:Plouzane,fr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Plouzane,fr
       recording weather for Plouzane, FR
    
     Processing for city # 301:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 301:Thunder Bay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thunder Bay,ca
       recording weather for Thunder Bay, CA
    
     Processing for city # 302:Severo-Kurilsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Severo-Kurilsk,ru
       recording weather for Severo-Kurilsk, RU
    
     Processing for city # 303:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 303:Asfi,ma
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asfi,ma
       city not found, retrying with different city... 
    
     Processing for city # 303:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 303:Olafsvik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Olafsvik,is
       city not found, retrying with different city... 
    
     Processing for city # 303:Saint George,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint George,bm
       Saint George, BM has already been added, attempting with another city
    
     Processing for city # 303:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       Tasiilaq, GL has already been added, attempting with another city
    
     Processing for city # 303:San Cristobal,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Cristobal,ec
       recording weather for San Cristobal, EC
    
     Processing for city # 304:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 304:Palabuhanratu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Palabuhanratu,id
       city not found, retrying with different city... 
    
     Processing for city # 304:Port Lincoln,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Lincoln,au
       Port Lincoln, AU has already been added, attempting with another city
    
     Processing for city # 304:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 304:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 304:Rawson,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rawson,ar
       recording weather for Rawson, AR
    
     Processing for city # 305:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 305:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 305:Alofi,nu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alofi,nu
       Alofi, NU has already been added, attempting with another city
    
     Processing for city # 305:Nome,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nome,us
       Nome, US has already been added, attempting with another city
    
     Processing for city # 305:Gambiran,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gambiran,id
       recording weather for Gambiran, ID
    
     Processing for city # 306:Haines Junction,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haines Junction,ca
       Haines Junction, CA has already been added, attempting with another city
    
     Processing for city # 306:Airai,pw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Airai,pw
       city not found, retrying with different city... 
    
     Processing for city # 306:Kanke,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kanke,in
       recording weather for Kanke, IN
    
     Processing for city # 307:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 307:Husavik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Husavik,is
       Husavik, IS has already been added, attempting with another city
    
     Processing for city # 307:Santa Teresa,ve
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Santa Teresa,ve
       recording weather for Santa Teresa, VE
    
     Processing for city # 308:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 308:Jucas,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jucas,br
       recording weather for Jucas, BR
    
     Processing for city # 309:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 309:Moose Factory,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moose Factory,ca
       Moose Factory, CA has already been added, attempting with another city
    
     Processing for city # 309:Wokingham,gb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Wokingham,gb
       recording weather for Wokingham, GB
    
     Processing for city # 310:Lethem,gy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lethem,gy
       recording weather for Lethem, GY
    
     Processing for city # 311:Port Hedland,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Hedland,au
       recording weather for Port Hedland, AU
    
     Processing for city # 312:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 312:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 312:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 312:Uglovskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Uglovskoye,ru
       recording weather for Uglovskoye, RU
    
     Processing for city # 313:Cayenne,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cayenne,gf
       Cayenne, GF has already been added, attempting with another city
    
     Processing for city # 313:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 313:Sitka,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sitka,us
       Sitka, US has already been added, attempting with another city
    
     Processing for city # 313:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 313:Flinders,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Flinders,au
       Flinders, AU has already been added, attempting with another city
    
     Processing for city # 313:Pimentel,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pimentel,pe
       recording weather for Pimentel, PE
    
     Processing for city # 314:Fare,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fare,pf
       recording weather for Fare, PF
    
     Processing for city # 315:Lindi,tz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lindi,tz
       recording weather for Lindi, TZ
    
     Processing for city # 316:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 316:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 316:Baker City,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Baker City,us
       recording weather for Baker City, US
    
     Processing for city # 317:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 317:Vostok,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vostok,ru
       Vostok, RU has already been added, attempting with another city
    
     Processing for city # 317:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 317:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 317:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 317:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 317:Codrington,ag
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Codrington,ag
       city not found, retrying with different city... 
    
     Processing for city # 317:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 317:Komsomolskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Komsomolskiy,ru
       recording weather for Komsomolskiy, RU
    
     Processing for city # 318:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 318:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 318:Vernon,fr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vernon,fr
       Vernon, FR has already been added, attempting with another city
    
     Processing for city # 318:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 318:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 318:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 318:Namibe,ao
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Namibe,ao
       Namibe, AO has already been added, attempting with another city
    
     Processing for city # 318:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 318:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 318:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 318:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 318:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 318:Tilichiki,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tilichiki,ru
       recording weather for Tilichiki, RU
    
     Processing for city # 319:Cap Malheureux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cap Malheureux,mu
       recording weather for Cap Malheureux, MU
    
     Processing for city # 320:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 320:Luau,ao
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luau,ao
       recording weather for Luau, AO
    
     Processing for city # 321:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 321:Severo-Kurilsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Severo-Kurilsk,ru
       Severo-Kurilsk, RU has already been added, attempting with another city
    
     Processing for city # 321:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 321:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 321:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 321:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 321:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 321:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 321:Yining,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yining,cn
       recording weather for Yining, CN
    
     Processing for city # 322:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 322:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 322:Codrington,ag
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Codrington,ag
       city not found, retrying with different city... 
    
     Processing for city # 322:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 322:Flin Flon,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Flin Flon,ca
       recording weather for Flin Flon, CA
    
     Processing for city # 323:Mehamn,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mehamn,no
       Mehamn, NO has already been added, attempting with another city
    
     Processing for city # 323:Pirapemas,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pirapemas,br
       recording weather for Pirapemas, BR
    
     Processing for city # 324:Naze,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Naze,jp
       recording weather for Naze, JP
    
     Processing for city # 325:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 325:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 325:Mys Shmidta,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mys Shmidta,ru
       city not found, retrying with different city... 
    
     Processing for city # 325:Stokmarknes,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Stokmarknes,no
       recording weather for Stokmarknes, NO
    
     Processing for city # 326:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 326:Zlatoust,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Zlatoust,ru
       recording weather for Zlatoust, RU
    
     Processing for city # 327:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 327:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 327:Marcona,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marcona,pe
       city not found, retrying with different city... 
    
     Processing for city # 327:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 327:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 327:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 327:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 327:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 327:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 327:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 327:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 327:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 327:Haines Junction,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haines Junction,ca
       Haines Junction, CA has already been added, attempting with another city
    
     Processing for city # 327:Shimoda,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shimoda,jp
       recording weather for Shimoda, JP
    
     Processing for city # 328:Boyolangu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Boyolangu,id
       recording weather for Boyolangu, ID
    
     Processing for city # 329:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 329:Mareeba,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mareeba,au
       Mareeba, AU has already been added, attempting with another city
    
     Processing for city # 329:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 329:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 329:Leningradskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leningradskiy,ru
       Leningradskiy, RU has already been added, attempting with another city
    
     Processing for city # 329:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 329:Aklavik,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aklavik,ca
       Aklavik, CA has already been added, attempting with another city
    
     Processing for city # 329:Lagoa,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lagoa,pt
       Lagoa, PT has already been added, attempting with another city
    
     Processing for city # 329:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 329:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 329:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 329:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 329:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       Mar del Plata, AR has already been added, attempting with another city
    
     Processing for city # 329:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 329:Arkadelphia,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arkadelphia,us
       recording weather for Arkadelphia, US
    
     Processing for city # 330:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 330:Coro,ve
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Coro,ve
       recording weather for Coro, VE
    
     Processing for city # 331:Solnechnyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Solnechnyy,ru
       Solnechnyy, RU has already been added, attempting with another city
    
     Processing for city # 331:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 331:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 331:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       Torbay, CA has already been added, attempting with another city
    
     Processing for city # 331:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 331:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 331:Kuching,my
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kuching,my
       Kuching, MY has already been added, attempting with another city
    
     Processing for city # 331:Sur,om
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sur,om
       recording weather for Sur, OM
    
     Processing for city # 332:Thetford Mines,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thetford Mines,ca
       recording weather for Thetford Mines, CA
    
     Processing for city # 333:Beringovskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Beringovskiy,ru
       recording weather for Beringovskiy, RU
    
     Processing for city # 334:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 334:Sao Joao Da Barra,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Joao Da Barra,br
       recording weather for Sao Joao da Barra, BR
    
     Processing for city # 335:Teya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Teya,ru
       recording weather for Teya, RU
    
     Processing for city # 336:Anchorage,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Anchorage,us
       recording weather for Anchorage, US
    
     Processing for city # 337:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 337:Namibe,ao
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Namibe,ao
       Namibe, AO has already been added, attempting with another city
    
     Processing for city # 337:Cidreira,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cidreira,br
       Cidreira, BR has already been added, attempting with another city
    
     Processing for city # 337:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 337:Winnemucca,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Winnemucca,us
       Winnemucca, US has already been added, attempting with another city
    
     Processing for city # 337:Dingle,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dingle,ie
       Dingle, IE has already been added, attempting with another city
    
     Processing for city # 337:Souillac,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Souillac,mu
       recording weather for Souillac, MU
    
     Processing for city # 338:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 338:San Cristobal,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Cristobal,ec
       San Cristobal, EC has already been added, attempting with another city
    
     Processing for city # 338:Severo-Kurilsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Severo-Kurilsk,ru
       Severo-Kurilsk, RU has already been added, attempting with another city
    
     Processing for city # 338:Toliary,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Toliary,mg
       city not found, retrying with different city... 
    
     Processing for city # 338:Yar-Sale,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yar-Sale,ru
       recording weather for Yar-Sale, RU
    
     Processing for city # 339:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 339:Sao Joao Da Barra,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Joao Da Barra,br
       Sao Joao da Barra, BR has already been added, attempting with another city
    
     Processing for city # 339:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 339:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 339:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 339:Umzimvubu,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Umzimvubu,za
       city not found, retrying with different city... 
    
     Processing for city # 339:Port Blair,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Blair,in
       recording weather for Port Blair, IN
    
     Processing for city # 340:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 340:Malatya,tr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Malatya,tr
       recording weather for Malatya, TR
    
     Processing for city # 341:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 341:Ozgon,kg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ozgon,kg
       city not found, retrying with different city... 
    
     Processing for city # 341:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 341:Kandalaksha,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kandalaksha,ru
       recording weather for Kandalaksha, RU
    
     Processing for city # 342:Robertson,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Robertson,za
       recording weather for Robertson, ZA
    
     Processing for city # 343:Port Hedland,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Hedland,au
       Port Hedland, AU has already been added, attempting with another city
    
     Processing for city # 343:Udachnyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Udachnyy,ru
       recording weather for Udachnyy, RU
    
     Processing for city # 344:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 344:Klaksvik,fo
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Klaksvik,fo
       recording weather for Klaksvik, FO
    
     Processing for city # 345:Nemuro,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nemuro,jp
       recording weather for Nemuro, JP
    
     Processing for city # 346:Dingle,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dingle,ie
       Dingle, IE has already been added, attempting with another city
    
     Processing for city # 346:Pishva,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pishva,ir
       recording weather for Pishva, IR
    
     Processing for city # 347:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 347:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 347:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 347:Maneadero,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maneadero,mx
       recording weather for Maneadero, MX
    
     Processing for city # 348:Victoria,sc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Victoria,sc
       Victoria, SC has already been added, attempting with another city
    
     Processing for city # 348:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 348:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 348:Chala,tz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chala,tz
       recording weather for Chala, TZ
    
     Processing for city # 349:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 349:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 349:Taybad,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taybad,ir
       recording weather for Taybad, IR
    
     Processing for city # 350:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 350:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 350:Kurumkan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kurumkan,ru
       recording weather for Kurumkan, RU
    
     Processing for city # 351:Severo-Kurilsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Severo-Kurilsk,ru
       Severo-Kurilsk, RU has already been added, attempting with another city
    
     Processing for city # 351:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 351:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 351:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 351:Moron,mn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moron,mn
       recording weather for Moron, MN
    
     Processing for city # 352:Lavrentiya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lavrentiya,ru
       recording weather for Lavrentiya, RU
    
     Processing for city # 353:Cabo San Lucas,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cabo San Lucas,mx
       Cabo San Lucas, MX has already been added, attempting with another city
    
     Processing for city # 353:College,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=College,us
       recording weather for College, US
    
     Processing for city # 354:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 354:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 354:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 354:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 354:Mangrol,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mangrol,in
       recording weather for Mangrol, IN
    
     Processing for city # 355:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 355:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 355:Assiniboia,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Assiniboia,ca
       recording weather for Assiniboia, CA
    
     Processing for city # 356:Wuwei,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Wuwei,cn
       recording weather for Wuwei, CN
    
     Processing for city # 357:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 357:Yar-Sale,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yar-Sale,ru
       Yar-Sale, RU has already been added, attempting with another city
    
     Processing for city # 357:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 357:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       Mar del Plata, AR has already been added, attempting with another city
    
     Processing for city # 357:Jumla,np
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jumla,np
       recording weather for Jumla, NP
    
     Processing for city # 358:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 358:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 358:Piquete,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Piquete,br
       recording weather for Piquete, BR
    
     Processing for city # 359:Ruatoria,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ruatoria,nz
       city not found, retrying with different city... 
    
     Processing for city # 359:Cabedelo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cabedelo,br
       recording weather for Cabedelo, BR
    
     Processing for city # 360:Kholodnyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kholodnyy,ru
       recording weather for Kholodnyy, RU
    
     Processing for city # 361:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 361:Manono,cd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Manono,cd
       recording weather for Manono, CD
    
     Processing for city # 362:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 362:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 362:Esperance,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esperance,au
       Esperance, AU has already been added, attempting with another city
    
     Processing for city # 362:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 362:Bandarbeyla,so
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bandarbeyla,so
       recording weather for Bandarbeyla, SO
    
     Processing for city # 363:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 363:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 363:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 363:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 363:Broome,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Broome,au
       recording weather for Broome, AU
    
     Processing for city # 364:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 364:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 364:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 364:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 364:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 364:Coihaique,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Coihaique,cl
       Coihaique, CL has already been added, attempting with another city
    
     Processing for city # 364:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 364:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 364:Umzimvubu,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Umzimvubu,za
       city not found, retrying with different city... 
    
     Processing for city # 364:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 364:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 364:Barabai,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barabai,id
       Barabai, ID has already been added, attempting with another city
    
     Processing for city # 364:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 364:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 364:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 364:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 364:Buala,sb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Buala,sb
       recording weather for Buala, SB
    
     Processing for city # 365:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 365:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 365:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 365:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 365:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 365:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 365:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 365:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 365:Saldanha,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saldanha,za
       recording weather for Saldanha, ZA
    
     Processing for city # 366:Payo,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Payo,ph
       city not found, retrying with different city... 
    
     Processing for city # 366:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 366:Osakarovka,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Osakarovka,kz
       recording weather for Osakarovka, KZ
    
     Processing for city # 367:Lasa,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lasa,cn
       city not found, retrying with different city... 
    
     Processing for city # 367:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 367:Byron Bay,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Byron Bay,au
       recording weather for Byron Bay, AU
    
     Processing for city # 368:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 368:San Cristobal,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Cristobal,ec
       San Cristobal, EC has already been added, attempting with another city
    
     Processing for city # 368:Aswan,eg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aswan,eg
       recording weather for Aswan, EG
    
     Processing for city # 369:Malartic,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Malartic,ca
       recording weather for Malartic, CA
    
     Processing for city # 370:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 370:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 370:Kruisfontein,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kruisfontein,za
       Kruisfontein, ZA has already been added, attempting with another city
    
     Processing for city # 370:Ngara,tz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ngara,tz
       recording weather for Ngara, TZ
    
     Processing for city # 371:Touros,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Touros,br
       Touros, BR has already been added, attempting with another city
    
     Processing for city # 371:Souillac,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Souillac,mu
       Souillac, MU has already been added, attempting with another city
    
     Processing for city # 371:Leningradskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leningradskiy,ru
       Leningradskiy, RU has already been added, attempting with another city
    
     Processing for city # 371:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 371:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 371:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 371:Mirpur Mathelo,pk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mirpur Mathelo,pk
       recording weather for Mirpur Mathelo, PK
    
     Processing for city # 372:Ishigaki,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ishigaki,jp
       recording weather for Ishigaki, JP
    
     Processing for city # 373:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 373:Tura,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tura,ru
       recording weather for Tura, RU
    
     Processing for city # 374:Palmer,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Palmer,us
       recording weather for Palmer, US
    
     Processing for city # 375:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 375:Lebu,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lebu,cl
       Lebu, CL has already been added, attempting with another city
    
     Processing for city # 375:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 375:Pisco,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pisco,pe
       recording weather for Pisco, PE
    
     Processing for city # 376:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 376:Gorin,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gorin,ru
       recording weather for Gorin, RU
    
     Processing for city # 377:Bengkulu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bengkulu,id
       city not found, retrying with different city... 
    
     Processing for city # 377:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 377:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 377:Trairi,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Trairi,br
       recording weather for Trairi, BR
    
     Processing for city # 378:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 378:Lobito,ao
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lobito,ao
       recording weather for Lobito, AO
    
     Processing for city # 379:Airai,pw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Airai,pw
       city not found, retrying with different city... 
    
     Processing for city # 379:Lagoa,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lagoa,pt
       Lagoa, PT has already been added, attempting with another city
    
     Processing for city # 379:Strezhevoy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Strezhevoy,ru
       recording weather for Strezhevoy, RU
    
     Processing for city # 380:Port Lincoln,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Lincoln,au
       Port Lincoln, AU has already been added, attempting with another city
    
     Processing for city # 380:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 380:Rio Grande,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rio Grande,br
       recording weather for Rio Grande, BR
    
     Processing for city # 381:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 381:Gorontalo,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gorontalo,id
       Gorontalo, ID has already been added, attempting with another city
    
     Processing for city # 381:Oranzherei,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Oranzherei,ru
       recording weather for Oranzherei, RU
    
     Processing for city # 382:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 382:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 382:Catamarca,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Catamarca,ar
       city not found, retrying with different city... 
    
     Processing for city # 382:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 382:Kharovsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kharovsk,ru
       recording weather for Kharovsk, RU
    
     Processing for city # 383:Iqaluit,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Iqaluit,ca
       Iqaluit, CA has already been added, attempting with another city
    
     Processing for city # 383:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 383:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 383:Rocha,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rocha,uy
       recording weather for Rocha, UY
    
     Processing for city # 384:Saint George,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint George,bm
       Saint George, BM has already been added, attempting with another city
    
     Processing for city # 384:Clarence Town,bs
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clarence Town,bs
       recording weather for Clarence Town, BS
    
     Processing for city # 385:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 385:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 385:Georgetown,gy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,gy
       Georgetown, GY has already been added, attempting with another city
    
     Processing for city # 385:Esperance,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esperance,au
       Esperance, AU has already been added, attempting with another city
    
     Processing for city # 385:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 385:Isangel,vu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Isangel,vu
       recording weather for Isangel, VU
    
     Processing for city # 386:Talcahuano,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Talcahuano,cl
       recording weather for Talcahuano, CL
    
     Processing for city # 387:Portland,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Portland,au
       recording weather for Portland, AU
    
     Processing for city # 388:Pringsewu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pringsewu,id
       Pringsewu, ID has already been added, attempting with another city
    
     Processing for city # 388:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 388:Fayetteville,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fayetteville,us
       recording weather for Fayetteville, US
    
     Processing for city # 389:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 389:Port Blair,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Blair,in
       Port Blair, IN has already been added, attempting with another city
    
     Processing for city # 389:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 389:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 389:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 389:Adrar,dz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Adrar,dz
       Adrar, DZ has already been added, attempting with another city
    
     Processing for city # 389:Provideniya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Provideniya,ru
       recording weather for Provideniya, RU
    
     Processing for city # 390:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 390:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 390:Rio Gallegos,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rio Gallegos,ar
       recording weather for Rio Gallegos, AR
    
     Processing for city # 391:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 391:Ferrol,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ferrol,es
       recording weather for Ferrol, ES
    
     Processing for city # 392:Lolua,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lolua,tv
       city not found, retrying with different city... 
    
     Processing for city # 392:Nizhneyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhneyansk,ru
       city not found, retrying with different city... 
    
     Processing for city # 392:Maningrida,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maningrida,au
       recording weather for Maningrida, AU
    
     Processing for city # 393:Yumen,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yumen,cn
       recording weather for Yumen, CN
    
     Processing for city # 394:Luderitz,na
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luderitz,na
       recording weather for Luderitz, NA
    
     Processing for city # 395:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 395:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 395:Hay River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hay River,ca
       recording weather for Hay River, CA
    
     Processing for city # 396:Nizhniy Tsasuchey,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhniy Tsasuchey,ru
       recording weather for Nizhniy Tsasuchey, RU
    
     Processing for city # 397:Tura,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tura,ru
       Tura, RU has already been added, attempting with another city
    
     Processing for city # 397:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 397:Tura,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tura,ru
       Tura, RU has already been added, attempting with another city
    
     Processing for city # 397:Trebinje,ba
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Trebinje,ba
       recording weather for Trebinje, BA
    
     Processing for city # 398:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       Carnarvon, AU has already been added, attempting with another city
    
     Processing for city # 398:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 398:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 398:Filadelfia,py
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Filadelfia,py
       recording weather for Filadelfia, PY
    
     Processing for city # 399:Faya,td
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faya,td
       city not found, retrying with different city... 
    
     Processing for city # 399:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 399:Attawapiskat,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Attawapiskat,ca
       city not found, retrying with different city... 
    
     Processing for city # 399:Les Escoumins,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Les Escoumins,ca
       recording weather for Les Escoumins, CA
    
     Processing for city # 400:Rocha,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rocha,uy
       Rocha, UY has already been added, attempting with another city
    
     Processing for city # 400:Mys Shmidta,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mys Shmidta,ru
       city not found, retrying with different city... 
    
     Processing for city # 400:Erzin,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Erzin,ru
       recording weather for Erzin, RU
    
     Processing for city # 401:Sinop,tr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sinop,tr
       recording weather for Sinop, TR
    
     Processing for city # 402:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 402:Langxiang,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Langxiang,cn
       recording weather for Langxiang, CN
    
     Processing for city # 403:Kargasok,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kargasok,ru
       recording weather for Kargasok, RU
    
     Processing for city # 404:Nalut,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nalut,ly
       Nalut, LY has already been added, attempting with another city
    
     Processing for city # 404:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 404:Bathsheba,bb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bathsheba,bb
       recording weather for Bathsheba, BB
    
     Processing for city # 405:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 405:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 405:Banda Aceh,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Banda Aceh,id
       recording weather for Banda Aceh, ID
    
     Processing for city # 406:Samaro,pk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Samaro,pk
       recording weather for Samaro, PK
    
     Processing for city # 407:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 407:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 407:Tarquinia,it
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tarquinia,it
       recording weather for Tarquinia, IT
    
     Processing for city # 408:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 408:Palembang,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Palembang,id
       recording weather for Palembang, ID
    
     Processing for city # 409:Tailai,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tailai,cn
       recording weather for Tailai, CN
    
     Processing for city # 410:Tanshui,tw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tanshui,tw
       city not found, retrying with different city... 
    
     Processing for city # 410:Sterlibashevo,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sterlibashevo,ru
       recording weather for Sterlibashevo, RU
    
     Processing for city # 411:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 411:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 411:Plettenberg Bay,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Plettenberg Bay,za
       recording weather for Plettenberg Bay, ZA
    
     Processing for city # 412:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 412:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 412:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 412:Port Blair,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Blair,in
       Port Blair, IN has already been added, attempting with another city
    
     Processing for city # 412:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 412:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 412:Vuktyl,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vuktyl,ru
       recording weather for Vuktyl, RU
    
     Processing for city # 413:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 413:Nizhneyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhneyansk,ru
       city not found, retrying with different city... 
    
     Processing for city # 413:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 413:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 413:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 413:Makarov,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Makarov,ru
       recording weather for Makarov, RU
    
     Processing for city # 414:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 414:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 414:Washougal,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Washougal,us
       recording weather for Washougal, US
    
     Processing for city # 415:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 415:Guerrero Negro,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Guerrero Negro,mx
       Guerrero Negro, MX has already been added, attempting with another city
    
     Processing for city # 415:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 415:Khash,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khash,ir
       recording weather for Khash, IR
    
     Processing for city # 416:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 416:Niigata,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Niigata,jp
       recording weather for Niigata, JP
    
     Processing for city # 417:Gamba,ga
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gamba,ga
       recording weather for Gamba, GA
    
     Processing for city # 418:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 418:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 418:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 418:Aklavik,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aklavik,ca
       Aklavik, CA has already been added, attempting with another city
    
     Processing for city # 418:Marsh Harbour,bs
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marsh Harbour,bs
       recording weather for Marsh Harbour, BS
    
     Processing for city # 419:Kamenskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kamenskoye,ru
       city not found, retrying with different city... 
    
     Processing for city # 419:Tazovskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tazovskiy,ru
       Tazovskiy, RU has already been added, attempting with another city
    
     Processing for city # 419:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 419:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 419:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       Carnarvon, AU has already been added, attempting with another city
    
     Processing for city # 419:Pevek,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pevek,ru
       Pevek, RU has already been added, attempting with another city
    
     Processing for city # 419:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 419:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 419:Ballina,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ballina,au
       Ballina, AU has already been added, attempting with another city
    
     Processing for city # 419:Bella Union,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bella Union,uy
       recording weather for Bella Union, UY
    
     Processing for city # 420:Papara,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Papara,pf
       city not found, retrying with different city... 
    
     Processing for city # 420:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 420:Pedernales,do
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pedernales,do
       recording weather for Pedernales, DO
    
     Processing for city # 421:Pisco,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pisco,pe
       Pisco, PE has already been added, attempting with another city
    
     Processing for city # 421:Surgut,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Surgut,ru
       recording weather for Surgut, RU
    
     Processing for city # 422:Veraval,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Veraval,in
       recording weather for Veraval, IN
    
     Processing for city # 423:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       Carnarvon, AU has already been added, attempting with another city
    
     Processing for city # 423:Roebourne,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Roebourne,au
       recording weather for Roebourne, AU
    
     Processing for city # 424:Ust-Nera,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ust-Nera,ru
       recording weather for Ust-Nera, RU
    
     Processing for city # 425:Inhambane,mz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Inhambane,mz
       recording weather for Inhambane, MZ
    
     Processing for city # 426:Hasaki,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hasaki,jp
       recording weather for Hasaki, JP
    
     Processing for city # 427:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 427:Bhadrapur,np
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bhadrapur,np
       recording weather for Bhadrapur, NP
    
     Processing for city # 428:Nehe,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nehe,cn
       recording weather for Nehe, CN
    
     Processing for city # 429:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 429:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 429:Lompoc,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lompoc,us
       Lompoc, US has already been added, attempting with another city
    
     Processing for city # 429:Lorengau,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lorengau,pg
       Lorengau, PG has already been added, attempting with another city
    
     Processing for city # 429:Saint-Avertin,fr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Avertin,fr
       recording weather for Saint-Avertin, FR
    
     Processing for city # 430:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 430:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 430:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 430:Matagami,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Matagami,ca
       recording weather for Matagami, CA
    
     Processing for city # 431:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 431:Kyenjojo,ug
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kyenjojo,ug
       recording weather for Kyenjojo, UG
    
     Processing for city # 432:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 432:Provideniya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Provideniya,ru
       Provideniya, RU has already been added, attempting with another city
    
     Processing for city # 432:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 432:Tullahoma,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tullahoma,us
       recording weather for Tullahoma, US
    
     Processing for city # 433:Jumla,np
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jumla,np
       Jumla, NP has already been added, attempting with another city
    
     Processing for city # 433:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 433:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 433:Ampanihy,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ampanihy,mg
       recording weather for Ampanihy, MG
    
     Processing for city # 434:Salme,ee
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Salme,ee
       city not found, retrying with different city... 
    
     Processing for city # 434:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 434:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 434:Lolua,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lolua,tv
       city not found, retrying with different city... 
    
     Processing for city # 434:Husavik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Husavik,is
       Husavik, IS has already been added, attempting with another city
    
     Processing for city # 434:Olinda,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Olinda,br
       recording weather for Olinda, BR
    
     Processing for city # 435:Aykhal,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aykhal,ru
       Aykhal, RU has already been added, attempting with another city
    
     Processing for city # 435:Broken Hill,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Broken Hill,au
       recording weather for Broken Hill, AU
    
     Processing for city # 436:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 436:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 436:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 436:Kayerkan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kayerkan,ru
       recording weather for Kayerkan, RU
    
     Processing for city # 437:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 437:Tumannyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tumannyy,ru
       city not found, retrying with different city... 
    
     Processing for city # 437:Lorengau,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lorengau,pg
       Lorengau, PG has already been added, attempting with another city
    
     Processing for city # 437:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 437:Lac Du Bonnet,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lac Du Bonnet,ca
       recording weather for Lac du Bonnet, CA
    
     Processing for city # 438:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 438:Spornoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Spornoye,ru
       recording weather for Spornoye, RU
    
     Processing for city # 439:Yermekeyevo,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yermekeyevo,ru
       recording weather for Yermekeyevo, RU
    
     Processing for city # 440:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 440:Yartsevo,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yartsevo,ru
       recording weather for Yartsevo, RU
    
     Processing for city # 441:Khonuu,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khonuu,ru
       city not found, retrying with different city... 
    
     Processing for city # 441:Longyearbyen,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Longyearbyen,sj
       Longyearbyen, SJ has already been added, attempting with another city
    
     Processing for city # 441:Varhaug,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Varhaug,no
       recording weather for Varhaug, NO
    
     Processing for city # 442:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 442:Kushmurun,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kushmurun,kz
       city not found, retrying with different city... 
    
     Processing for city # 442:Severo-Kurilsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Severo-Kurilsk,ru
       Severo-Kurilsk, RU has already been added, attempting with another city
    
     Processing for city # 442:Vila Velha,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vila Velha,br
       Vila Velha, BR has already been added, attempting with another city
    
     Processing for city # 442:Newport,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Newport,us
       recording weather for Newport, US
    
     Processing for city # 443:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 443:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 443:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 443:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 443:Terney,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Terney,ru
       recording weather for Terney, RU
    
     Processing for city # 444:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 444:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 444:Peniche,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Peniche,pt
       recording weather for Peniche, PT
    
     Processing for city # 445:Janakpur Road,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Janakpur Road,in
       city not found, retrying with different city... 
    
     Processing for city # 445:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 445:Kaitangata,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kaitangata,nz
       Kaitangata, NZ has already been added, attempting with another city
    
     Processing for city # 445:Umm Kaddadah,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Umm Kaddadah,sd
       Umm Kaddadah, SD has already been added, attempting with another city
    
     Processing for city # 445:Kawalu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kawalu,id
       recording weather for Kawalu, ID
    
     Processing for city # 446:Sorong,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sorong,id
       Sorong, ID has already been added, attempting with another city
    
     Processing for city # 446:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 446:Husavik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Husavik,is
       Husavik, IS has already been added, attempting with another city
    
     Processing for city # 446:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 446:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 446:Namwala,zm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Namwala,zm
       recording weather for Namwala, ZM
    
     Processing for city # 447:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 447:Phan Thiet,vn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Phan Thiet,vn
       recording weather for Phan Thiet, VN
    
     Processing for city # 448:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 448:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 448:Bela,pk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bela,pk
       recording weather for Bela, PK
    
     Processing for city # 449:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 449:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       Bambous Virieux, MU has already been added, attempting with another city
    
     Processing for city # 449:Havoysund,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Havoysund,no
       recording weather for Havoysund, NO
    
     Processing for city # 450:Labrea,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Labrea,br
       city not found, retrying with different city... 
    
     Processing for city # 450:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 450:Tchollire,cm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tchollire,cm
       recording weather for Tchollire, CM
    
     Processing for city # 451:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 451:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 451:Mecca,sa
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mecca,sa
       recording weather for Mecca, SA
    
     Processing for city # 452:Shunyi,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shunyi,cn
       recording weather for Shunyi, CN
    
     Processing for city # 453:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 453:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 453:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 453:Ban Phai,th
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ban Phai,th
       recording weather for Ban Phai, TH
    
     Processing for city # 454:Gat,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Gat,ly
       city not found, retrying with different city... 
    
     Processing for city # 454:Jesup,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jesup,us
       recording weather for Jesup, US
    
     Processing for city # 455:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 455:Srednekolymsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Srednekolymsk,ru
       recording weather for Srednekolymsk, RU
    
     Processing for city # 456:Cidreira,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cidreira,br
       Cidreira, BR has already been added, attempting with another city
    
     Processing for city # 456:Tazovskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tazovskiy,ru
       Tazovskiy, RU has already been added, attempting with another city
    
     Processing for city # 456:Ponta Do Sol,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,pt
       Ponta do Sol, PT has already been added, attempting with another city
    
     Processing for city # 456:Teano,it
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Teano,it
       recording weather for Teano, IT
    
     Processing for city # 457:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 457:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 457:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 457:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 457:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 457:Jieshi,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jieshi,cn
       recording weather for Jieshi, CN
    
     Processing for city # 458:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 458:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 458:Hambantota,lk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hambantota,lk
       recording weather for Hambantota, LK
    
     Processing for city # 459:Samusu,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Samusu,ws
       city not found, retrying with different city... 
    
     Processing for city # 459:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 459:Cidreira,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cidreira,br
       Cidreira, BR has already been added, attempting with another city
    
     Processing for city # 459:Waddan,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Waddan,ly
       recording weather for Waddan, LY
    
     Processing for city # 460:Alyangula,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alyangula,au
       Alyangula, AU has already been added, attempting with another city
    
     Processing for city # 460:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 460:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 460:Srednekolymsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Srednekolymsk,ru
       Srednekolymsk, RU has already been added, attempting with another city
    
     Processing for city # 460:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 460:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 460:Dubbo,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dubbo,au
       recording weather for Dubbo, AU
    
     Processing for city # 461:Aripuana,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aripuana,br
       recording weather for Aripuana, BR
    
     Processing for city # 462:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 462:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 462:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 462:Luderitz,na
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luderitz,na
       Luderitz, NA has already been added, attempting with another city
    
     Processing for city # 462:Senneterre,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Senneterre,ca
       recording weather for Senneterre, CA
    
     Processing for city # 463:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 463:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 463:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 463:Provideniya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Provideniya,ru
       Provideniya, RU has already been added, attempting with another city
    
     Processing for city # 463:Pitimbu,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pitimbu,br
       Pitimbu, BR has already been added, attempting with another city
    
     Processing for city # 463:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 463:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 463:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 463:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 463:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 463:Flinders,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Flinders,au
       Flinders, AU has already been added, attempting with another city
    
     Processing for city # 463:Bolungarvik,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bolungarvik,is
       city not found, retrying with different city... 
    
     Processing for city # 463:Cap Malheureux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cap Malheureux,mu
       Cap Malheureux, MU has already been added, attempting with another city
    
     Processing for city # 463:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 463:Alice Springs,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alice Springs,au
       recording weather for Alice Springs, AU
    
     Processing for city # 464:Coihaique,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Coihaique,cl
       Coihaique, CL has already been added, attempting with another city
    
     Processing for city # 464:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 464:Norman Wells,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Norman Wells,ca
       Norman Wells, CA has already been added, attempting with another city
    
     Processing for city # 464:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 464:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 464:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 464:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 464:Maasin,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maasin,ph
       recording weather for Maasin, PH
    
     Processing for city # 465:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 465:Ascension,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ascension,mx
       city not found, retrying with different city... 
    
     Processing for city # 465:Necochea,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Necochea,ar
       Necochea, AR has already been added, attempting with another city
    
     Processing for city # 465:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 465:Lorengau,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lorengau,pg
       Lorengau, PG has already been added, attempting with another city
    
     Processing for city # 465:Cayenne,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cayenne,gf
       Cayenne, GF has already been added, attempting with another city
    
     Processing for city # 465:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 465:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 465:Bengkulu,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bengkulu,id
       city not found, retrying with different city... 
    
     Processing for city # 465:Shizunai,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Shizunai,jp
       recording weather for Shizunai, JP
    
     Processing for city # 466:Port Shepstone,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Shepstone,za
       recording weather for Port Shepstone, ZA
    
     Processing for city # 467:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 467:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 467:Luganville,vu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luganville,vu
       recording weather for Luganville, VU
    
     Processing for city # 468:Ilulissat,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ilulissat,gl
       Ilulissat, GL has already been added, attempting with another city
    
     Processing for city # 468:Katsuura,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Katsuura,jp
       Katsuura, JP has already been added, attempting with another city
    
     Processing for city # 468:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 468:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 468:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       Tasiilaq, GL has already been added, attempting with another city
    
     Processing for city # 468:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 468:Saeby,dk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saeby,dk
       recording weather for Saeby, DK
    
     Processing for city # 469:Iquitos,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Iquitos,pe
       recording weather for Iquitos, PE
    
     Processing for city # 470:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 470:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 470:Spirit River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Spirit River,ca
       recording weather for Spirit River, CA
    
     Processing for city # 471:Sirohi,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sirohi,in
       recording weather for Sirohi, IN
    
     Processing for city # 472:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 472:Hamilton,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hamilton,bm
       recording weather for Hamilton, BM
    
     Processing for city # 473:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 473:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 473:Castanos,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castanos,mx
       recording weather for Castanos, MX
    
     Processing for city # 474:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 474:Colesberg,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Colesberg,za
       Colesberg, ZA has already been added, attempting with another city
    
     Processing for city # 474:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 474:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 474:Tezu,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tezu,in
       recording weather for Tezu, IN
    
     Processing for city # 475:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 475:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 475:Menzelinsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Menzelinsk,ru
       recording weather for Menzelinsk, RU
    
     Processing for city # 476:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 476:Lavrentiya,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lavrentiya,ru
       Lavrentiya, RU has already been added, attempting with another city
    
     Processing for city # 476:Kidal,ml
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kidal,ml
       recording weather for Kidal, ML
    
     Processing for city # 477:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 477:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 477:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 477:Pisco,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pisco,pe
       Pisco, PE has already been added, attempting with another city
    
     Processing for city # 477:Tasiilaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tasiilaq,gl
       Tasiilaq, GL has already been added, attempting with another city
    
     Processing for city # 477:Comodoro Rivadavia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Comodoro Rivadavia,ar
       Comodoro Rivadavia, AR has already been added, attempting with another city
    
     Processing for city # 477:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 477:Port Maria,jm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Maria,jm
       recording weather for Port Maria, JM
    
     Processing for city # 478:Ambon,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ambon,id
       recording weather for Ambon, ID
    
     Processing for city # 479:Lucatan,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lucatan,ph
       city not found, retrying with different city... 
    
     Processing for city # 479:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 479:Leningradskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leningradskiy,ru
       Leningradskiy, RU has already been added, attempting with another city
    
     Processing for city # 479:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 479:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 479:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 479:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 479:Sterling,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sterling,us
       recording weather for Sterling, US
    
     Processing for city # 480:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 480:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 480:Isla Aguada,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Isla Aguada,mx
       recording weather for Isla Aguada, MX
    
     Processing for city # 481:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 481:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 481:Svetlogorsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Svetlogorsk,ru
       recording weather for Svetlogorsk, RU
    
     Processing for city # 482:Esperance,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esperance,au
       Esperance, AU has already been added, attempting with another city
    
     Processing for city # 482:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 482:Tokmak,kg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tokmak,kg
       city not found, retrying with different city... 
    
     Processing for city # 482:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 482:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 482:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 482:Hofn,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hofn,is
       Hofn, IS has already been added, attempting with another city
    
     Processing for city # 482:Isangel,vu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Isangel,vu
       Isangel, VU has already been added, attempting with another city
    
     Processing for city # 482:Uribia,co
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Uribia,co
       recording weather for Uribia, CO
    
     Processing for city # 483:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 483:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 483:Kavieng,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kavieng,pg
       Kavieng, PG has already been added, attempting with another city
    
     Processing for city # 483:Kapit,my
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapit,my
       recording weather for Kapit, MY
    
     Processing for city # 484:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 484:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 484:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 484:Killybegs,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Killybegs,ie
       recording weather for Killybegs, IE
    
     Processing for city # 485:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 485:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 485:Savalou,bj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Savalou,bj
       recording weather for Savalou, BJ
    
     Processing for city # 486:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 486:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 486:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 486:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 486:Rabo De Peixe,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rabo De Peixe,pt
       recording weather for Rabo de Peixe, PT
    
     Processing for city # 487:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 487:Kamina,cd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kamina,cd
       recording weather for Kamina, CD
    
     Processing for city # 488:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 488:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 488:Emirdag,tr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Emirdag,tr
       recording weather for Emirdag, TR
    
     Processing for city # 489:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 489:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 489:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 489:Talcahuano,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Talcahuano,cl
       Talcahuano, CL has already been added, attempting with another city
    
     Processing for city # 489:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 489:Eldikan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Eldikan,ru
       city not found, retrying with different city... 
    
     Processing for city # 489:Luderitz,na
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Luderitz,na
       Luderitz, NA has already been added, attempting with another city
    
     Processing for city # 489:Belushya Guba,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Belushya Guba,ru
       city not found, retrying with different city... 
    
     Processing for city # 489:Half Moon Bay,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Half Moon Bay,us
       recording weather for Half Moon Bay, US
    
     Processing for city # 490:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 490:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 490:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 490:Moscow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Moscow,us
       recording weather for Moscow, US
    
     Processing for city # 491:New Norfolk,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=New Norfolk,au
       New Norfolk, AU has already been added, attempting with another city
    
     Processing for city # 491:Maralal,ke
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maralal,ke
       recording weather for Maralal, KE
    
     Processing for city # 492:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 492:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 492:Sao Jose Da Coroa Grande,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Jose Da Coroa Grande,br
       Sao Jose da Coroa Grande, BR has already been added, attempting with another city
    
     Processing for city # 492:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 492:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 492:Troutdale,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Troutdale,us
       recording weather for Troutdale, US
    
     Processing for city # 493:Nuevo Progreso,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nuevo Progreso,mx
       recording weather for Nuevo Progreso, MX
    
     Processing for city # 494:Lhokseumawe,id
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lhokseumawe,id
       recording weather for Lhokseumawe, ID
    
     Processing for city # 495:Mergui,mm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mergui,mm
       city not found, retrying with different city... 
    
     Processing for city # 495:Pont-Audemer,fr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pont-Audemer,fr
       recording weather for Pont-Audemer, FR
    
     Processing for city # 496:Talnakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Talnakh,ru
       Talnakh, RU has already been added, attempting with another city
    
     Processing for city # 496:Saleaula,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saleaula,ws
       city not found, retrying with different city... 
    
     Processing for city # 496:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 496:Balimo,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Balimo,pg
       city not found, retrying with different city... 
    
     Processing for city # 496:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 496:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 496:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 496:Chabahar,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chabahar,ir
       recording weather for Chabahar, IR
    
     Processing for city # 497:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 497:Pisco,pe
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pisco,pe
       Pisco, PE has already been added, attempting with another city
    
     Processing for city # 497:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 497:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 497:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 497:Malakal,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Malakal,sd
       city not found, retrying with different city... 
    
     Processing for city # 497:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       Faanui, PF has already been added, attempting with another city
    
     Processing for city # 497:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 497:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 497:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 497:Kajaani,fi
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kajaani,fi
       recording weather for Kajaani, FI
    
     Processing for city # 498:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 498:Ambanja,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ambanja,mg
       recording weather for Ambanja, MG
    
     Processing for city # 499:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 499:Poya,nc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Poya,nc
       recording weather for Poya, NC
    
     Processing for city # 500:Quzhou,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Quzhou,cn
       recording weather for Quzhou, CN
    
     Processing for city # 501:Niihama,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Niihama,jp
       recording weather for Niihama, JP
    
     Processing for city # 502:Sinnamary,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sinnamary,gf
       recording weather for Sinnamary, GF
    
     Processing for city # 503:Zihuatanejo,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Zihuatanejo,mx
       recording weather for Zihuatanejo, MX
    
     Processing for city # 504:Voyvozh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Voyvozh,ru
       recording weather for Voyvozh, RU
    
     Processing for city # 505:Souillac,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Souillac,mu
       Souillac, MU has already been added, attempting with another city
    
     Processing for city # 505:Nouadhibou,mr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nouadhibou,mr
       Nouadhibou, MR has already been added, attempting with another city
    
     Processing for city # 505:Kamenskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kamenskoye,ru
       city not found, retrying with different city... 
    
     Processing for city # 505:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 505:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 505:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 505:Attawapiskat,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Attawapiskat,ca
       city not found, retrying with different city... 
    
     Processing for city # 505:Mongo,td
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mongo,td
       recording weather for Mongo, TD
    
     Processing for city # 506:San Quintin,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Quintin,mx
       city not found, retrying with different city... 
    
     Processing for city # 506:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 506:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 506:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 506:Camapua,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Camapua,br
       recording weather for Camapua, BR
    
     Processing for city # 507:Awjilah,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Awjilah,ly
       recording weather for Awjilah, LY
    
     Processing for city # 508:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 508:Durres,al
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Durres,al
       recording weather for Durres, AL
    
     Processing for city # 509:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 509:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 509:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 509:Amderma,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Amderma,ru
       city not found, retrying with different city... 
    
     Processing for city # 509:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 509:Kamina,cd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kamina,cd
       Kamina, CD has already been added, attempting with another city
    
     Processing for city # 509:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 509:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 509:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 509:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 509:Udachnyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Udachnyy,ru
       Udachnyy, RU has already been added, attempting with another city
    
     Processing for city # 509:Lolua,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lolua,tv
       city not found, retrying with different city... 
    
     Processing for city # 509:Saskylakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saskylakh,ru
       Saskylakh, RU has already been added, attempting with another city
    
     Processing for city # 509:Tawkar,sd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tawkar,sd
       city not found, retrying with different city... 
    
     Processing for city # 509:Buckingham,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Buckingham,ca
       recording weather for Buckingham, CA
    
     Processing for city # 510:Lompoc,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lompoc,us
       Lompoc, US has already been added, attempting with another city
    
     Processing for city # 510:Vanavara,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vanavara,ru
       recording weather for Vanavara, RU
    
     Processing for city # 511:Yar-Sale,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yar-Sale,ru
       Yar-Sale, RU has already been added, attempting with another city
    
     Processing for city # 511:Ust-Nera,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ust-Nera,ru
       Ust-Nera, RU has already been added, attempting with another city
    
     Processing for city # 511:Talnakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Talnakh,ru
       Talnakh, RU has already been added, attempting with another city
    
     Processing for city # 511:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 511:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 511:Fereydun Kenar,ir
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fereydun Kenar,ir
       recording weather for Fereydun Kenar, IR
    
     Processing for city # 512:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 512:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 512:Samusu,ws
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Samusu,ws
       city not found, retrying with different city... 
    
     Processing for city # 512:Taolanaro,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taolanaro,mg
       city not found, retrying with different city... 
    
     Processing for city # 512:Harlingen,nl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Harlingen,nl
       recording weather for Harlingen, NL
    
     Processing for city # 513:Kulhudhuffushi,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kulhudhuffushi,mv
       Kulhudhuffushi, MV has already been added, attempting with another city
    
     Processing for city # 513:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 513:Saint-Philippe,re
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Philippe,re
       Saint-Philippe, RE has already been added, attempting with another city
    
     Processing for city # 513:Amderma,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Amderma,ru
       city not found, retrying with different city... 
    
     Processing for city # 513:Hobyo,so
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobyo,so
       Hobyo, SO has already been added, attempting with another city
    
     Processing for city # 513:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 513:Nadym,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nadym,ru
       recording weather for Nadym, RU
    
     Processing for city # 514:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 514:Dzhusaly,kz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dzhusaly,kz
       city not found, retrying with different city... 
    
     Processing for city # 514:Tilichiki,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tilichiki,ru
       Tilichiki, RU has already been added, attempting with another city
    
     Processing for city # 514:Esperance,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Esperance,au
       Esperance, AU has already been added, attempting with another city
    
     Processing for city # 514:Saint-Andre-Avellin,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Andre-Avellin,ca
       recording weather for Saint-Andre-Avellin, CA
    
     Processing for city # 515:Dingle,ie
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dingle,ie
       Dingle, IE has already been added, attempting with another city
    
     Processing for city # 515:Dublin,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dublin,us
       recording weather for Dublin, US
    
     Processing for city # 516:Baoning,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Baoning,cn
       recording weather for Baoning, CN
    
     Processing for city # 517:Ulcinj,me
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ulcinj,me
       city not found, retrying with different city... 
    
     Processing for city # 517:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 517:Teknaf,bd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Teknaf,bd
       recording weather for Teknaf, BD
    
     Processing for city # 518:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 518:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 518:Elizabethtown,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Elizabethtown,us
       recording weather for Elizabethtown, US
    
     Processing for city # 519:Tumannyy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tumannyy,ru
       city not found, retrying with different city... 
    
     Processing for city # 519:Straumen,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Straumen,no
       recording weather for Straumen, NO
    
     Processing for city # 520:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 520:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 520:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 520:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 520:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 520:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 520:Ancud,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ancud,cl
       Ancud, CL has already been added, attempting with another city
    
     Processing for city # 520:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 520:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 520:Marfino,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marfino,ru
       recording weather for Marfino, RU
    
     Processing for city # 521:Sao Jose Da Coroa Grande,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Jose Da Coroa Grande,br
       Sao Jose da Coroa Grande, BR has already been added, attempting with another city
    
     Processing for city # 521:Aleksandrov Gay,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Aleksandrov Gay,ru
       recording weather for Aleksandrov Gay, RU
    
     Processing for city # 522:Guapi,co
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Guapi,co
       recording weather for Guapi, CO
    
     Processing for city # 523:Oussouye,sn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Oussouye,sn
       recording weather for Oussouye, SN
    
     Processing for city # 524:Fuente Palmera,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fuente Palmera,es
       recording weather for Fuente Palmera, ES
    
     Processing for city # 525:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 525:Cap Malheureux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cap Malheureux,mu
       Cap Malheureux, MU has already been added, attempting with another city
    
     Processing for city # 525:Grand Gaube,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand Gaube,mu
       Grand Gaube, MU has already been added, attempting with another city
    
     Processing for city # 525:Port Hardy,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Hardy,ca
       Port Hardy, CA has already been added, attempting with another city
    
     Processing for city # 525:Nishihara,jp
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nishihara,jp
       recording weather for Nishihara, JP
    
     Processing for city # 526:Taoudenni,ml
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taoudenni,ml
       recording weather for Taoudenni, ML
    
     Processing for city # 527:Norman Wells,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Norman Wells,ca
       Norman Wells, CA has already been added, attempting with another city
    
     Processing for city # 527:Marienburg,sr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marienburg,sr
       recording weather for Marienburg, SR
    
     Processing for city # 528:Holme,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Holme,no
       city not found, retrying with different city... 
    
     Processing for city # 528:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 528:Porto Walter,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Porto Walter,br
       recording weather for Porto Walter, BR
    
     Processing for city # 529:Arroyo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arroyo,us
       recording weather for Arroyo, US
    
     Processing for city # 530:Saint-Philippe,re
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Philippe,re
       Saint-Philippe, RE has already been added, attempting with another city
    
     Processing for city # 530:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       Torbay, CA has already been added, attempting with another city
    
     Processing for city # 530:Ferrol,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ferrol,es
       Ferrol, ES has already been added, attempting with another city
    
     Processing for city # 530:Nakhon Phanom,th
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nakhon Phanom,th
       recording weather for Nakhon Phanom, TH
    
     Processing for city # 531:Wukari,ng
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Wukari,ng
       recording weather for Wukari, NG
    
     Processing for city # 532:Tuatapere,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuatapere,nz
       Tuatapere, NZ has already been added, attempting with another city
    
     Processing for city # 532:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 532:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 532:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 532:Nioro,ml
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nioro,ml
       city not found, retrying with different city... 
    
     Processing for city # 532:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 532:Isangel,vu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Isangel,vu
       Isangel, VU has already been added, attempting with another city
    
     Processing for city # 532:Dartford,gb
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dartford,gb
       recording weather for Dartford, GB
    
     Processing for city # 533:Pevek,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pevek,ru
       Pevek, RU has already been added, attempting with another city
    
     Processing for city # 533:Ranong,th
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ranong,th
       recording weather for Ranong, TH
    
     Processing for city # 534:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 534:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 534:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 534:Jackson,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jackson,us
       recording weather for Jackson, US
    
     Processing for city # 535:Waipawa,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Waipawa,nz
       recording weather for Waipawa, NZ
    
     Processing for city # 536:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       Mar del Plata, AR has already been added, attempting with another city
    
     Processing for city # 536:Tabou,ci
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tabou,ci
       Tabou, CI has already been added, attempting with another city
    
     Processing for city # 536:Miri,my
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Miri,my
       recording weather for Miri, MY
    
     Processing for city # 537:High Prairie,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=High Prairie,ca
       recording weather for High Prairie, CA
    
     Processing for city # 538:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 538:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 538:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 538:Longyearbyen,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Longyearbyen,sj
       Longyearbyen, SJ has already been added, attempting with another city
    
     Processing for city # 538:Victoria,sc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Victoria,sc
       Victoria, SC has already been added, attempting with another city
    
     Processing for city # 538:Bethel,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bethel,us
       Bethel, US has already been added, attempting with another city
    
     Processing for city # 538:Cayenne,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cayenne,gf
       Cayenne, GF has already been added, attempting with another city
    
     Processing for city # 538:Cotonou,bj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cotonou,bj
       Cotonou, BJ has already been added, attempting with another city
    
     Processing for city # 538:Cayenne,gf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cayenne,gf
       Cayenne, GF has already been added, attempting with another city
    
     Processing for city # 538:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 538:Riyadh,sa
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Riyadh,sa
       recording weather for Riyadh, SA
    
     Processing for city # 539:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 539:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 539:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 539:Pandan,ph
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pandan,ph
       recording weather for Pandan, PH
    
     Processing for city # 540:Alofi,nu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Alofi,nu
       Alofi, NU has already been added, attempting with another city
    
     Processing for city # 540:Muros,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Muros,es
       recording weather for Muros, ES
    
     Processing for city # 541:Vila Franca Do Campo,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vila Franca Do Campo,pt
       recording weather for Vila Franca do Campo, PT
    
     Processing for city # 542:Saint George,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint George,bm
       Saint George, BM has already been added, attempting with another city
    
     Processing for city # 542:Leh,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Leh,in
       Leh, IN has already been added, attempting with another city
    
     Processing for city # 542:Chokurdakh,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chokurdakh,ru
       Chokurdakh, RU has already been added, attempting with another city
    
     Processing for city # 542:Ruston,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ruston,us
       recording weather for Ruston, US
    
     Processing for city # 543:Warrington,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Warrington,us
       recording weather for Warrington, US
    
     Processing for city # 544:Queanbeyan,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Queanbeyan,au
       recording weather for Queanbeyan, AU
    
     Processing for city # 545:Rodeo,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rodeo,mx
       recording weather for Rodeo, MX
    
     Processing for city # 546:Palasbari,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Palasbari,in
       recording weather for Palasbari, IN
    
     Processing for city # 547:Santa Ines,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Santa Ines,br
       city not found, retrying with different city... 
    
     Processing for city # 547:Lokosovo,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lokosovo,ru
       recording weather for Lokosovo, RU
    
     Processing for city # 548:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       Torbay, CA has already been added, attempting with another city
    
     Processing for city # 548:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 548:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 548:Kavaratti,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kavaratti,in
       recording weather for Kavaratti, IN
    
     Processing for city # 549:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 549:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       Torbay, CA has already been added, attempting with another city
    
     Processing for city # 549:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 549:Hamilton,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hamilton,bm
       Hamilton, BM has already been added, attempting with another city
    
     Processing for city # 549:Barentsburg,sj
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barentsburg,sj
       city not found, retrying with different city... 
    
     Processing for city # 549:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 549:Jalu,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jalu,ly
       recording weather for Jalu, LY
    
     Processing for city # 550:Ponta Delgada,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Delgada,pt
       recording weather for Ponta Delgada, PT
    
     Processing for city # 551:Lagoa,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lagoa,pt
       Lagoa, PT has already been added, attempting with another city
    
     Processing for city # 551:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 551:Faanui,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Faanui,pf
       Faanui, PF has already been added, attempting with another city
    
     Processing for city # 551:Arlington,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arlington,us
       recording weather for Arlington, US
    
     Processing for city # 552:Ostrovnoy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ostrovnoy,ru
       recording weather for Ostrovnoy, RU
    
     Processing for city # 553:Ahipara,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ahipara,nz
       Ahipara, NZ has already been added, attempting with another city
    
     Processing for city # 553:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 553:San Cristobal,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Cristobal,ec
       San Cristobal, EC has already been added, attempting with another city
    
     Processing for city # 553:Hamilton,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hamilton,bm
       Hamilton, BM has already been added, attempting with another city
    
     Processing for city # 553:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 553:Pacific Grove,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pacific Grove,us
       recording weather for Pacific Grove, US
    
     Processing for city # 554:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 554:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 554:Avarua,ck
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avarua,ck
       Avarua, CK has already been added, attempting with another city
    
     Processing for city # 554:Dunedin,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dunedin,nz
       recording weather for Dunedin, NZ
    
     Processing for city # 555:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 555:Mocuba,mz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mocuba,mz
       recording weather for Mocuba, MZ
    
     Processing for city # 556:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 556:Caetite,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Caetite,br
       recording weather for Caetite, BR
    
     Processing for city # 557:Sorvag,fo
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sorvag,fo
       city not found, retrying with different city... 
    
     Processing for city # 557:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 557:Flin Flon,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Flin Flon,ca
       Flin Flon, CA has already been added, attempting with another city
    
     Processing for city # 557:Caravelas,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Caravelas,br
       Caravelas, BR has already been added, attempting with another city
    
     Processing for city # 557:Nshamba,tz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nshamba,tz
       recording weather for Nshamba, TZ
    
     Processing for city # 558:Nanortalik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nanortalik,gl
       recording weather for Nanortalik, GL
    
     Processing for city # 559:Kavieng,pg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kavieng,pg
       Kavieng, PG has already been added, attempting with another city
    
     Processing for city # 559:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 559:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 559:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 559:Port Macquarie,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Macquarie,au
       recording weather for Port Macquarie, AU
    
     Processing for city # 560:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 560:Yaan,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yaan,cn
       city not found, retrying with different city... 
    
     Processing for city # 560:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 560:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 560:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 560:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 560:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 560:Bambous Virieux,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bambous Virieux,mu
       Bambous Virieux, MU has already been added, attempting with another city
    
     Processing for city # 560:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 560:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 560:Fort Nelson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Fort Nelson,ca
       Fort Nelson, CA has already been added, attempting with another city
    
     Processing for city # 560:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 560:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 560:Melilla,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Melilla,es
       recording weather for Melilla, ES
    
     Processing for city # 561:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 561:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 561:Maneromango,tz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Maneromango,tz
       recording weather for Maneromango, TZ
    
     Processing for city # 562:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 562:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 562:Avera,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Avera,pf
       city not found, retrying with different city... 
    
     Processing for city # 562:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 562:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 562:Hohr-Grenzhausen,de
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hohr-Grenzhausen,de
       recording weather for Hohr-Grenzhausen, DE
    
     Processing for city # 563:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 563:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 563:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 563:Haibowan,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haibowan,cn
       city not found, retrying with different city... 
    
     Processing for city # 563:Kahului,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kahului,us
       Kahului, US has already been added, attempting with another city
    
     Processing for city # 563:Bereda,so
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bereda,so
       city not found, retrying with different city... 
    
     Processing for city # 563:Tessalit,ml
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tessalit,ml
       recording weather for Tessalit, ML
    
     Processing for city # 564:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 564:Cherskiy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cherskiy,ru
       Cherskiy, RU has already been added, attempting with another city
    
     Processing for city # 564:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 564:Narsaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Narsaq,gl
       Narsaq, GL has already been added, attempting with another city
    
     Processing for city # 564:Ugoofaaru,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ugoofaaru,mv
       recording weather for Ugoofaaru, MV
    
     Processing for city # 565:Mahalapye,bw
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahalapye,bw
       recording weather for Mahalapye, BW
    
     Processing for city # 566:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 566:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 566:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 566:Yanchukan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yanchukan,ru
       city not found, retrying with different city... 
    
     Processing for city # 566:Victoria,sc
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Victoria,sc
       Victoria, SC has already been added, attempting with another city
    
     Processing for city # 566:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 566:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 566:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 566:Thompson,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Thompson,ca
       Thompson, CA has already been added, attempting with another city
    
     Processing for city # 566:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 566:Lander,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lander,us
       recording weather for Lander, US
    
     Processing for city # 567:Melilla,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Melilla,es
       Melilla, ES has already been added, attempting with another city
    
     Processing for city # 567:San Patricio,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=San Patricio,mx
       recording weather for San Patricio, MX
    
     Processing for city # 568:Soller,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Soller,es
       recording weather for Soller, ES
    
     Processing for city # 569:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 569:Carnarvon,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carnarvon,au
       Carnarvon, AU has already been added, attempting with another city
    
     Processing for city # 569:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 569:Torbay,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Torbay,ca
       Torbay, CA has already been added, attempting with another city
    
     Processing for city # 569:Half Moon Bay,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Half Moon Bay,us
       Half Moon Bay, US has already been added, attempting with another city
    
     Processing for city # 569:Toliary,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Toliary,mg
       city not found, retrying with different city... 
    
     Processing for city # 569:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 569:Arlit,ne
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arlit,ne
       Arlit, NE has already been added, attempting with another city
    
     Processing for city # 569:Dikson,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Dikson,ru
       Dikson, RU has already been added, attempting with another city
    
     Processing for city # 569:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 569:Georgetown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Georgetown,sh
       Georgetown, SH has already been added, attempting with another city
    
     Processing for city # 569:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 569:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 569:Haines Junction,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Haines Junction,ca
       Haines Junction, CA has already been added, attempting with another city
    
     Processing for city # 569:Nileshwar,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nileshwar,in
       recording weather for Nileshwar, IN
    
     Processing for city # 570:Chumikan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chumikan,ru
       recording weather for Chumikan, RU
    
     Processing for city # 571:Grand Forks,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand Forks,ca
       recording weather for Grand Forks, CA
    
     Processing for city # 572:Bulgan,mn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bulgan,mn
       Bulgan, MN has already been added, attempting with another city
    
     Processing for city # 572:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 572:Kaitangata,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kaitangata,nz
       Kaitangata, NZ has already been added, attempting with another city
    
     Processing for city # 572:Taiyuan,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Taiyuan,cn
       recording weather for Taiyuan, CN
    
     Processing for city # 573:Boende,cd
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Boende,cd
       recording weather for Boende, CD
    
     Processing for city # 574:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 574:Kodiak,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kodiak,us
       Kodiak, US has already been added, attempting with another city
    
     Processing for city # 574:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 574:Ponta Do Sol,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ponta Do Sol,cv
       Ponta do Sol, CV has already been added, attempting with another city
    
     Processing for city # 574:Clyde River,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Clyde River,ca
       Clyde River, CA has already been added, attempting with another city
    
     Processing for city # 574:Hithadhoo,mv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hithadhoo,mv
       Hithadhoo, MV has already been added, attempting with another city
    
     Processing for city # 574:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 574:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 574:Pula,hr
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Pula,hr
       recording weather for Pula, HR
    
     Processing for city # 575:Illoqqortoormiut,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Illoqqortoormiut,gl
       city not found, retrying with different city... 
    
     Processing for city # 575:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 575:Teguise,es
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Teguise,es
       recording weather for Teguise, ES
    
     Processing for city # 576:Marsh Harbour,bs
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Marsh Harbour,bs
       Marsh Harbour, BS has already been added, attempting with another city
    
     Processing for city # 576:Ondorhaan,mn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ondorhaan,mn
       city not found, retrying with different city... 
    
     Processing for city # 576:Albany,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Albany,au
       Albany, AU has already been added, attempting with another city
    
     Processing for city # 576:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 576:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 576:Ostrovnoy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ostrovnoy,ru
       Ostrovnoy, RU has already been added, attempting with another city
    
     Processing for city # 576:Ambilobe,mg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ambilobe,mg
       recording weather for Ambilobe, MG
    
     Processing for city # 577:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 577:Butaritari,ki
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Butaritari,ki
       Butaritari, KI has already been added, attempting with another city
    
     Processing for city # 577:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 577:Saint-Philippe,re
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Saint-Philippe,re
       Saint-Philippe, RE has already been added, attempting with another city
    
     Processing for city # 577:Ostrovnoy,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ostrovnoy,ru
       Ostrovnoy, RU has already been added, attempting with another city
    
     Processing for city # 577:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 577:Kenora,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kenora,ca
       recording weather for Kenora, CA
    
     Processing for city # 578:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 578:Lebu,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Lebu,cl
       Lebu, CL has already been added, attempting with another city
    
     Processing for city # 578:Port Elizabeth,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Elizabeth,za
       Port Elizabeth, ZA has already been added, attempting with another city
    
     Processing for city # 578:Chuy,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chuy,uy
       Chuy, UY has already been added, attempting with another city
    
     Processing for city # 578:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 578:Mar Del Plata,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mar Del Plata,ar
       Mar del Plata, AR has already been added, attempting with another city
    
     Processing for city # 578:Kihei,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kihei,us
       Kihei, US has already been added, attempting with another city
    
     Processing for city # 578:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 578:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 578:Kapaa,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Kapaa,us
       Kapaa, US has already been added, attempting with another city
    
     Processing for city # 578:Sao Filipe,cv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sao Filipe,cv
       Sao Filipe, CV has already been added, attempting with another city
    
     Processing for city # 578:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 578:Nanortalik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nanortalik,gl
       Nanortalik, GL has already been added, attempting with another city
    
     Processing for city # 578:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 578:Grand River South East,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Grand River South East,mu
       city not found, retrying with different city... 
    
     Processing for city # 578:Jawar,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jawar,in
       recording weather for Jawar, IN
    
     Processing for city # 579:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 579:Surt,ly
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Surt,ly
       recording weather for Surt, LY
    
     Processing for city # 580:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 580:Juneau,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Juneau,us
       Juneau, US has already been added, attempting with another city
    
     Processing for city # 580:Carutapera,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Carutapera,br
       recording weather for Carutapera, BR
    
     Processing for city # 581:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 581:Cape Town,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cape Town,za
       Cape Town, ZA has already been added, attempting with another city
    
     Processing for city # 581:Suntar,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Suntar,ru
       recording weather for Suntar, RU
    
     Processing for city # 582:Yellowknife,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Yellowknife,ca
       Yellowknife, CA has already been added, attempting with another city
    
     Processing for city # 582:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 582:Tiksi,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tiksi,ru
       Tiksi, RU has already been added, attempting with another city
    
     Processing for city # 582:Rey Bouba,cm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rey Bouba,cm
       recording weather for Rey Bouba, CM
    
     Processing for city # 583:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 583:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 583:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 583:Mehamn,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mehamn,no
       Mehamn, NO has already been added, attempting with another city
    
     Processing for city # 583:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 583:Upernavik,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Upernavik,gl
       Upernavik, GL has already been added, attempting with another city
    
     Processing for city # 583:Mahebourg,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mahebourg,mu
       Mahebourg, MU has already been added, attempting with another city
    
     Processing for city # 583:Tuktoyaktuk,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tuktoyaktuk,ca
       Tuktoyaktuk, CA has already been added, attempting with another city
    
     Processing for city # 583:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 583:Chipurupalle,in
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Chipurupalle,in
       recording weather for Chipurupalle, IN
    
     Processing for city # 584:Actopan,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Actopan,mx
       recording weather for Actopan, MX
    
     Processing for city # 585:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 585:Vestmannaeyjar,is
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vestmannaeyjar,is
       Vestmannaeyjar, IS has already been added, attempting with another city
    
     Processing for city # 585:Korla,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Korla,cn
       recording weather for Korla, CN
    
     Processing for city # 586:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 586:Souillac,mu
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Souillac,mu
       Souillac, MU has already been added, attempting with another city
    
     Processing for city # 586:Cabo San Lucas,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cabo San Lucas,mx
       Cabo San Lucas, MX has already been added, attempting with another city
    
     Processing for city # 586:Setermoen,no
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Setermoen,no
       recording weather for Setermoen, NO
    
     Processing for city # 587:East London,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=East London,za
       East London, ZA has already been added, attempting with another city
    
     Processing for city # 587:Koslan,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Koslan,ru
       recording weather for Koslan, RU
    
     Processing for city # 588:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 588:Mount Isa,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mount Isa,au
       recording weather for Mount Isa, AU
    
     Processing for city # 589:Castro,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Castro,cl
       Castro, CL has already been added, attempting with another city
    
     Processing for city # 589:Ilhabela,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ilhabela,br
       recording weather for Ilhabela, BR
    
     Processing for city # 590:Asau,tv
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Asau,tv
       city not found, retrying with different city... 
    
     Processing for city # 590:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 590:Xinqing,cn
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Xinqing,cn
       recording weather for Xinqing, CN
    
     Processing for city # 591:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 591:Atuona,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Atuona,pf
       Atuona, PF has already been added, attempting with another city
    
     Processing for city # 591:Hermanus,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hermanus,za
       Hermanus, ZA has already been added, attempting with another city
    
     Processing for city # 591:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 591:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 591:Port Alfred,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Alfred,za
       Port Alfred, ZA has already been added, attempting with another city
    
     Processing for city # 591:Nikolskoye,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikolskoye,ru
       Nikolskoye, RU has already been added, attempting with another city
    
     Processing for city # 591:Khatanga,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Khatanga,ru
       Khatanga, RU has already been added, attempting with another city
    
     Processing for city # 591:Rikitea,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rikitea,pf
       Rikitea, PF has already been added, attempting with another city
    
     Processing for city # 591:Ushuaia,ar
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ushuaia,ar
       Ushuaia, AR has already been added, attempting with another city
    
     Processing for city # 591:Norman Wells,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Norman Wells,ca
       Norman Wells, CA has already been added, attempting with another city
    
     Processing for city # 591:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 591:Srednekolymsk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Srednekolymsk,ru
       Srednekolymsk, RU has already been added, attempting with another city
    
     Processing for city # 591:Nizhneyansk,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nizhneyansk,ru
       city not found, retrying with different city... 
    
     Processing for city # 591:Port Hawkesbury,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port Hawkesbury,ca
       recording weather for Port Hawkesbury, CA
    
     Processing for city # 592:Coihaique,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Coihaique,cl
       Coihaique, CL has already been added, attempting with another city
    
     Processing for city # 592:Byron Bay,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Byron Bay,au
       Byron Bay, AU has already been added, attempting with another city
    
     Processing for city # 592:Bluff,nz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bluff,nz
       Bluff, NZ has already been added, attempting with another city
    
     Processing for city # 592:Miles City,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Miles City,us
       recording weather for Miles City, US
    
     Processing for city # 593:Barrow,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Barrow,us
       Barrow, US has already been added, attempting with another city
    
     Processing for city # 593:Punta Arenas,cl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Punta Arenas,cl
       Punta Arenas, CL has already been added, attempting with another city
    
     Processing for city # 593:Qaanaaq,gl
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Qaanaaq,gl
       Qaanaaq, GL has already been added, attempting with another city
    
     Processing for city # 593:Meitingen,de
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Meitingen,de
       recording weather for Meitingen, DE
    
     Processing for city # 594:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 594:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 594:Ribeira Grande,pt
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Ribeira Grande,pt
       Ribeira Grande, PT has already been added, attempting with another city
    
     Processing for city # 594:Rocha,uy
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Rocha,uy
       Rocha, UY has already been added, attempting with another city
    
     Processing for city # 594:Nikel,ru
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Nikel,ru
       recording weather for Nikel, RU
    
     Processing for city # 595:Bredasdorp,za
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Bredasdorp,za
       Bredasdorp, ZA has already been added, attempting with another city
    
     Processing for city # 595:Prince Rupert,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Prince Rupert,ca
       recording weather for Prince Rupert, CA
    
     Processing for city # 596:Cabo San Lucas,mx
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Cabo San Lucas,mx
       Cabo San Lucas, MX has already been added, attempting with another city
    
     Processing for city # 596:Puerto Ayora,ec
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Puerto Ayora,ec
       Puerto Ayora, EC has already been added, attempting with another city
    
     Processing for city # 596:Jamestown,sh
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Jamestown,sh
       Jamestown, SH has already been added, attempting with another city
    
     Processing for city # 596:Hobart,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hobart,au
       Hobart, AU has already been added, attempting with another city
    
     Processing for city # 596:Mataura,pf
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Mataura,pf
       city not found, retrying with different city... 
    
     Processing for city # 596:Tupelo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Tupelo,us
       recording weather for Tupelo, US
    
     Processing for city # 597:Vaini,to
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Vaini,to
       Vaini, TO has already been added, attempting with another city
    
     Processing for city # 597:Louisbourg,ca
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Louisbourg,ca
       city not found, retrying with different city... 
    
     Processing for city # 597:Hamilton,bm
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hamilton,bm
       Hamilton, BM has already been added, attempting with another city
    
     Processing for city # 597:Hilo,us
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Hilo,us
       Hilo, US has already been added, attempting with another city
    
     Processing for city # 597:Angoche,mz
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Angoche,mz
       recording weather for Angoche, MZ
    
     Processing for city # 598:Arraial Do Cabo,br
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Arraial Do Cabo,br
       Arraial do Cabo, BR has already been added, attempting with another city
    
     Processing for city # 598:Matara,lk
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Matara,lk
       recording weather for Matara, LK
    
     Processing for city # 599:Sembe,cg
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Sembe,cg
       recording weather for Sembe, CG
    
     Processing for city # 600:Busselton,au
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Busselton,au
       Busselton, AU has already been added, attempting with another city
    
     Processing for city # 600:Port-Gentil,ga
     Requested: http://api.openweathermap.org/data/2.5/weather?appid=73826dff6d2151f8356b24df7781d600&units=imperial&q=Port-Gentil,ga
       recording weather for Port-Gentil, GA
    
    Requested for 600 cities.
    


```python
#creating Data frame
weather_dict = {
    'City':cities,
    'Country':countries,
    'Latitude':lat,
    'Longitude':lon,
    'Temperature(F)':Temperature,
    'Humidity':humidity,
    'WindSpeed (MPH)':windSpeed,
    'Cloudiness':cloudiness
}
cities_weather = pd.DataFrame(weather_dict,columns=pd.Index(["City","Country","Latitude",
                                                             "Longitude","Temperature(F)","Humidity","WindSpeed (MPH)","Cloudiness"]))

```


```python

```


```python
cities_weather.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature(F)</th>
      <th>Humidity</th>
      <th>WindSpeed (MPH)</th>
      <th>Cloudiness</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Katsuura</td>
      <td>JP</td>
      <td>33.93</td>
      <td>134.50</td>
      <td>49.70</td>
      <td>84</td>
      <td>1.70</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Port Alfred</td>
      <td>ZA</td>
      <td>-33.59</td>
      <td>26.89</td>
      <td>68.78</td>
      <td>98</td>
      <td>3.04</td>
      <td>44</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ushuaia</td>
      <td>AR</td>
      <td>-54.81</td>
      <td>-68.31</td>
      <td>44.60</td>
      <td>87</td>
      <td>6.93</td>
      <td>40</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Pangnirtung</td>
      <td>CA</td>
      <td>66.15</td>
      <td>-65.72</td>
      <td>32.00</td>
      <td>82</td>
      <td>10.29</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Busselton</td>
      <td>AU</td>
      <td>-33.64</td>
      <td>115.35</td>
      <td>63.56</td>
      <td>100</td>
      <td>16.69</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
</div>




```python
cities_weather.to_csv("cities_weather.csv")
```

### plotting latitude Vs Temperature


```python
#x,y values for the plot
lat=cities_weather["Latitude"]
Temp= cities_weather["Temperature(F)"]
```


```python
plt.scatter(Temp,lat)
```




    <matplotlib.collections.PathCollection at 0x1f40ca4c4e0>




```python
plt.xlabel="Temperature(F)"
plt.ylabel="Latitude"
```


```python
plt.grid()
```


```python
plt.show()
```


![png](output_13_0.png)


### plotting latitude Vs Humidity


```python
#Assigning humidity
humidity=cities_weather["Humidity"]
```


```python
plt.scatter(humidity,lat)
```




    <matplotlib.collections.PathCollection at 0x1f40caed940>




```python
plt.grid()
```


```python
plt.show()
```


![png](output_18_0.png)


### plotting latitude Vs windSpeed


```python
windspeed=cities_weather["WindSpeed (MPH)"]
```


```python
plt.scatter(windspeed,lat)
```




    <matplotlib.collections.PathCollection at 0x1f40cd27940>




```python
plt.grid()
```


```python
plt.show()
```


![png](output_23_0.png)


### plotting latitude Vs Cloudiness


```python
cloudiness= cities_weather["Cloudiness"]
```


```python
plt.scatter(lat,cloudiness)
```




    <matplotlib.collections.PathCollection at 0x1f40cdc6390>




```python
plt.grid()
```


```python
plt.show()
```


![png](output_28_0.png)

